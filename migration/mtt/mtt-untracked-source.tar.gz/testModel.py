"""
测试教师模型的准确率
"""

import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
from torchvision.models import resnet18
import os

# 配置
device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"使用设备: {device}")

# 加载教师模型
print("\n加载教师模型...")
teacher = resnet18(num_classes=10)
teacher.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
teacher.maxpool = nn.Identity()

teacher_path = 'teacher_resnet18_cifar10.pth'
if not os.path.exists(teacher_path):
    print(f"❌ 错误: 找不到教师模型文件 {teacher_path}")
    print("请先运行 train_teacher.py 训练教师模型")
    exit(1)

# 加载权重
state_dict = torch.load(teacher_path, map_location='cpu')
teacher.load_state_dict(state_dict)
teacher = teacher.to(device)
teacher.eval()
print(f"✅ 教师模型加载成功")

# 准备测试数据
print("\n准备测试数据...")
transform_test = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])

testset = torchvision.datasets.CIFAR10(
    root='./data', train=False, download=True, transform=transform_test
)
testloader = torch.utils.data.DataLoader(
    testset, batch_size=128, shuffle=False, num_workers=2
)
print(f"✅ 测试集加载完成，共 {len(testset)} 张图片")

# 测试教师模型
print("\n测试教师模型准确率...")
correct = 0
total = 0

with torch.no_grad():
    for i, (inputs, targets) in enumerate(testloader):
        inputs, targets = inputs.to(device), targets.to(device)
        outputs = teacher(inputs)
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()
        
        if (i + 1) % 10 == 0:
            print(f"  处理批次 {i+1}/{len(testloader)}")

teacher_acc = 100. * correct / total
print(f"\n{'='*50}")
print(f"教师模型测试准确率: {teacher_acc:.2f}%")
print(f"{'='*50}")

# 显示每个类别的准确率
print("\n每个类别的准确率:")
class_correct = [0] * 10
class_total = [0] * 10
classes = ['airplane', 'automobile', 'bird', 'cat', 'deer',
           'dog', 'frog', 'horse', 'ship', 'truck']

with torch.no_grad():
    for inputs, targets in testloader:
        inputs, targets = inputs.to(device), targets.to(device)
        outputs = teacher(inputs)
        _, predicted = outputs.max(1)
        c = (predicted == targets).squeeze()
        for i in range(len(targets)):
            label = targets[i]
            class_correct[label] += c[i].item()
            class_total[label] += 1

for i in range(10):
    acc = 100. * class_correct[i] / class_total[i]
    print(f"  {classes[i]}: {acc:.2f}%")

print(f"\n建议:")
if teacher_acc < 50:
    print("  ⚠️ 教师模型准确率过低，建议重新训练")
    print("  运行: python train_teacher.py")
elif teacher_acc < 65:
    print("  ⚠️ 教师模型准确率一般，可以考虑继续训练")
else:
    print("  ✅ 教师模型准确率良好，可以用于蒸馏训练")