"""
PLDK Baseline Training with Model Saving
基于 pldk_train_v2.py 修改，添加模型保存功能
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
from utils import get_network, TensorDataset, get_eval_pool, get_dataset
import os
import time

# ==========================================
# 1. 定义数据增强
# ==========================================
class DiffAugment(nn.Module):
    def __init__(self):
        super().__init__()
        self.aug = nn.Sequential(
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
        )
    
    def forward(self, x):
        return self.aug(x)

def pldk_train():
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Device: {device}")
    print("="*60)
    print("PLDK Baseline Training (with model saving)")
    print("="*60)

    # ==========================================
    # 2. 加载 Teacher 模型
    # ==========================================
    from torchvision.models import resnet18
    teacher = resnet18(num_classes=10)
    teacher.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
    teacher.maxpool = nn.Identity()
    
    teacher_path = 'teacher_resnet18_cifar10.pth'
    if not os.path.exists(teacher_path):
        print(f"错误: 找不到 {teacher_path}，请先运行 train_teacher.py")
        return
        
    teacher.load_state_dict(torch.load(teacher_path, map_location='cpu'))
    teacher = teacher.to(device)
    teacher.eval()

    # 验证 Teacher 在测试集上的准确率
    print("\n正在验证 Teacher 模型性能...")
    class Args:
        def __init__(self):
            self.zca = False
    
    args = Args()
    _, _, _, _, _, _, _, _, test_loader, _, _, _ = get_dataset('CIFAR10', './data', 256, args=args)
    correct_t = 0
    total_t = 0
    with torch.no_grad():
        for inputs, targets in test_loader:
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = teacher(inputs)
            _, predicted = outputs.max(1)
            total_t += targets.size(0)
            correct_t += predicted.eq(targets).sum().item()
    teacher_acc = 100. * correct_t / total_t
    print(f"Teacher Test Accuracy: {teacher_acc:.2f}%")
    
    if teacher_acc < 50:
        print("警告: Teacher 准确率过低！请检查 train_teacher.py 是否训练成功。")

    # ==========================================
    # 3. 加载蒸馏数据 & 归一化处理
    # ==========================================
    print("\n加载蒸馏数据...")
    data_path = "images_best.pt"
    if not os.path.exists(data_path):
        import glob
        files = glob.glob("**/images_best.pt", recursive=True)
        if files:
            data_path = files[0]
            print(f"自动找到蒸馏数据: {data_path}")
        else:
            print("错误: 找不到 images_best.pt")
            return

    # ⭐ 修复：先加载到CPU，避免直接占用GPU显存
    images_train = torch.load(data_path, map_location='cpu')
    labels_path = data_path.replace('images_best.pt', 'labels_best.pt')
    labels_train = torch.load(labels_path, map_location='cpu')
    
    print(f"Loaded Distilled Data: {images_train.shape}")
    print(f"总图片数: {len(images_train)}")

    # 归一化检查
    if images_train.max() > 1.0 and images_train.min() < 0:
        print("检测到数据已归一化，跳过手动归一化步骤。")
    else:
        print("检测到数据可能未归一化 (0-1 range)，正在应用 CIFAR-10 Normalization...")
        transform_norm = transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))
        images_train = transform_norm(images_train)

    # ==========================================
    # 4. 准备 Student
    # ==========================================
    print("\n初始化学生模型...")
    student = get_network('ConvNet', channel=3, num_classes=10, im_size=(32, 32)).to(device)
    optimizer = torch.optim.SGD(student.parameters(), lr=0.01, momentum=0.9, weight_decay=5e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=1000)
    augmentor = DiffAugment().to(device)

    # PLDK 参数
    T_temp = 4.0 
    alpha = 0.5
    
    print("\n开始训练...")
    print("="*70)
    print(f"{'Epoch':<8} {'Loss':<12} {'KD Loss':<12} {'CE Loss':<12} {'Test Acc':<10}")
    print("="*70)
    
    startTime = time.time()
    
    # ⭐ 创建数据加载器（数据保持在CPU，训练时再移到GPU）
    class CPUTensorDataset(torch.utils.data.Dataset):
        def __init__(self, images, labels):
            self.images = images  # CPU
            self.labels = labels  # CPU
        def __getitem__(self, index):
            return self.images[index], self.labels[index]
        def __len__(self):
            return len(self.images)
    
    train_dataset = CPUTensorDataset(images_train, labels_train)
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=128, shuffle=True, num_workers=0)

    epochs = 1000
    best_acc = 0.0  # ⭐ 记录最佳准确率
    
    for epoch in range(epochs):
        student.train()
        total_loss = 0
        total_kd = 0
        total_ce = 0
        
        for imgs, labs in train_loader:
            # ⭐ 只在此时将数据移到GPU
            imgs, labs = imgs.to(device), labs.to(device)
            
            # 应用数据增强
            imgs = augmentor(imgs)
            
            with torch.no_grad():
                teacher_logits = teacher(imgs)
            
            student_logits = student(imgs)
            
            # Loss Calculation
            kd_loss = nn.KLDivLoss(reduction='batchmean')(
                F.log_softmax(student_logits / T_temp, dim=1),
                F.softmax(teacher_logits / T_temp, dim=1)
            ) * (T_temp * T_temp)
            
            ce_loss = F.cross_entropy(student_logits, labs)
            loss = alpha * kd_loss + (1 - alpha) * ce_loss
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
            total_kd += kd_loss.item()
            total_ce += ce_loss.item()
            
        scheduler.step()
        
        # 每100轮评估一次
        if (epoch + 1) % 100 == 0 or epoch == 0:
            student.eval()
            correct = 0
            total = 0
            with torch.no_grad():
                for inputs, targets in test_loader:
                    inputs, targets = inputs.to(device), targets.to(device)
                    outputs = student(inputs)
                    _, predicted = outputs.max(1)
                    total += targets.size(0)
                    correct += predicted.eq(targets).sum().item()
            acc = 100. * correct / total
            
            avg_loss = total_loss / len(train_loader)
            avg_kd = total_kd / len(train_loader)
            avg_ce = total_ce / len(train_loader)
            
            print(f"{epoch+1:<8} {avg_loss:<12.4f} {avg_kd:<12.4f} {avg_ce:<12.4f} {acc:<10.2f}")
            
            # ⭐ 保存最佳模型
            if acc > best_acc:
                best_acc = acc
                torch.save(student.state_dict(), 'best_pldk.pth')
                # print(f"    👑 新最佳模型！准确率: {acc:.2f}% -> saved to best_pldk.pth")

    endTime = time.time()
    print("="*70)
    print(f"\n训练完成！")
    print(f"总用时: {endTime - startTime:.2f}秒")
    print(f"最佳准确率: {best_acc:.2f}%")
    print(f"模型已保存到: best_pldk.pth")

if __name__ == '__main__':
    pldk_train()