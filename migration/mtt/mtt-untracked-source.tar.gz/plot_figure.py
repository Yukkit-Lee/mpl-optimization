"""
学术风格 matplotlib 绘图脚本（v3）
数据来源：
  - 图1 : Table 2（CIFAR-10 / STL-10 隐私-效用权衡散点图）
  - 图2 : Table 3（异构蒸馏基线对比，按数据集拆成两张独立图）
  - 图3 : Table 4（跨范式 DP / 正则化基线对比，按数据集拆成两张独立图）

输出文件（PDF + PNG，300 dpi）：
  fig1_tradeoff.pdf / .png
  fig2_cifar10.pdf  / .png
  fig2_stl10.pdf    / .png
  fig3_cifar10.pdf  / .png
  fig3_stl10.pdf    / .png
"""

import os
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.transforms as mtransforms
from matplotlib.lines import Line2D

# ══════════════════════════════════════════════════════════════════════════════
# ❶  全局字体 / 字号设置
#    如果你想统一改整张图的字号或字体，只改这一块即可
# ══════════════════════════════════════════════════════════════════════════════
matplotlib.rcParams.update({
    "font.family":       "serif",
    "font.serif":        ["Times New Roman", "DejaVu Serif"],
    "font.size":         9,          # ← 全局基础字号，改这里会影响所有文字
    "axes.titlesize":    9,          # ← 子图标题字号（(a)(b) 那行）
    "axes.labelsize":    9,          # ← 坐标轴标题字号（"Test Acc (%)" 等）
    "xtick.labelsize":   8,          # ← 横轴刻度文字字号
    "ytick.labelsize":   8,          # ← 纵轴刻度文字字号
    "legend.fontsize":   7.5,        # ← 图例文字字号
    "legend.framealpha": 0.9,        # ← 图例背景透明度（0=全透明，1=不透明）
    "legend.edgecolor":  "#cccccc",  # ← 图例边框颜色
    "axes.spines.top":   False,      # ← 隐藏顶部边框线
    "axes.spines.right": False,      # ← 隐藏右侧边框线
    "figure.dpi":        150,
    "savefig.dpi":       300,        # ← 输出分辨率，论文一般 300 dpi 足够
    "savefig.bbox":      "tight",
})

# ══════════════════════════════════════════════════════════════════════════════
# ❷  横轴文字对齐微调（图2 / 图3 独立控制）
#    如果柱子和标签没对齐，先改 ha，再改 rotation，最后用 dx/dy 精调
#      rotation : 文字旋转角度（度）
#      ha       : 水平对齐，"left" / "center" / "right"
#      pad      : 标签距坐标轴的距离（点 pt）
#      dx / dy  : 横/纵向微调（点 pt），正数=右/上，负数=左/下
# ══════════════════════════════════════════════════════════════════════════════
XTICK_TUNE_FIG2 = {"rotation": 20, "ha": "center", "pad": 2.0, "dx": 0.0, "dy": 0.0}
XTICK_TUNE_FIG3 = {"rotation": 28, "ha": "center", "pad": 2.0, "dx": 0.0, "dy": 0.0}

# 图3 中 DP-SGD 两个标签较长，单独缩小字号避免挤叠
# 键 = 标签文字，值 = 字号；不想特殊处理就把对应行删掉
FIG3_SPECIAL_TICK_FONTS = {
    "DP-SGD\n(ε=198.5)": 6.6,   # ← 可改字号，或直接删掉这行恢复默认
    "DP-SGD\n(ε=50.2)":  6.6,   # ← 同上
}

# ══════════════════════════════════════════════════════════════════════════════
# ❸  全局配色总表
#    所有图共用下面这几个颜色变量；想改配色优先改这里
#    颜色格式：十六进制 "#RRGGBB"，也可用 "steelblue" 等颜色名
# ══════════════════════════════════════════════════════════════════════════════
C_STANDARD  = "#7B8FA1"   # 散点图：传统防御方法（No Defense / Regu）的颜色
C_DISTILL   = "#8B6F47"   # 散点图：蒸馏基线方法（DMP / PLDK）的颜色
C_OURS_PLDK = "#4A6D8C"   # 散点图：PLDK + MPC 的颜色
C_OURS      = "#1C3557"   # 所有图：Ours（我们方法）的颜色，越深越突出
C_RANDOM    = "#AA3333"   # 所有图：random-guess 参考线 / 参考文字的颜色

# ── 图2 柱状图配色 ─────────────────────────────────────────────────────────────
# bar_cols_base : Test Acc 柱子颜色，4 个方法从左到右由浅到深，最后一个是 Ours
bar_cols_base = ["#A9BDD4", "#7B9CB8", "#5A7FA3", C_OURS]

# bar_cols_Ab / bar_cols_Aw : 隐私图 Ab / Aw 两组柱子颜色
# 同样从浅到深，最后一个是 Ours；Ab 用偏红色系，Aw 用偏紫色系
bar_cols_Ab = ["#C8A8A8", "#B08080", "#96605C", "#7A2E2A"]   # ← Priv Acc (Ab) 四根柱的颜色
bar_cols_Aw = ["#C9BCD0", "#B09AB8", "#907098", "#5C3A6A"]   # ← Priv Acc (Aw) 四根柱的颜色

# ── 图3 柱状图配色 ─────────────────────────────────────────────────────────────
# 前5个基线用灰蓝色梯度，最后一个是 Ours（深蓝）
# 想换色系就把前5个全换成同一色系的深浅版本
RAMP = [
    "#C5CDD8",   # ← PATE 柱颜色
    "#ADBAC9",   # ← DP-SGD (ε=198.5) 柱颜色
    "#96A8BB",   # ← DP-SGD (ε=50.2) 柱颜色
    "#7F96AC",   # ← HierarchicalDP 柱颜色
    "#68849D",   # ← QL-PGD 柱颜色
    C_OURS,      # ← Ours 柱颜色（复用全局 C_OURS）
]

# ══════════════════════════════════════════════════════════════════════════════
# ❹  输出路径
# ══════════════════════════════════════════════════════════════════════════════
OUT = "./papers_figure"
os.makedirs(OUT, exist_ok=True)

# ══════════════════════════════════════════════════════════════════════════════
# ❺  图1 数据（来自 Table 2）
#    每行格式：(方法名, Test Acc, Priv Acc(Ab), 类别编号)
#    类别：0=传统防御  1=蒸馏基线  2=PLDK+MPC  3=Ours
# ══════════════════════════════════════════════════════════════════════════════
data_t2_cifar = [
    ("No Defense",       67.46, 76.80, 0),
    ("Regu (WD+LS)",     53.20, 53.00, 0),
    ("DMP",              65.00, 50.60, 1),
    ("PLDK",             69.30, 50.21, 1),
    ("PLDK + MPC",       65.61, 50.22, 2),
    ("MPC + KA\n(Ours)", 64.36, 49.62, 3),
]
data_t2_stl = [
    ("No Defense",       59.58, 73.18, 0),
    ("Regu (WD+LS)",     55.73, 68.02, 0),
    ("DMP",              45.86, 51.08, 1),
    ("PLDK",             40.90, 49.38, 1),
    ("PLDK + MPC",       41.88, 49.25, 2),
    ("MPC + KA\n(Ours)", 49.51, 49.85, 3),
]

# 每类方法的散点样式：(形状, 颜色, 点大小, zorder层级, 边框宽度)
# 形状可选："o"圆  "s"方  "D"菱形  "^"三角  "*"星 等
cat_style = {
    0: ("o",  C_STANDARD,  52,  2, 0.7),   # ← 传统防御：圆点，蓝灰色，大小52
    1: ("s",  C_DISTILL,   52,  2, 0.7),   # ← 蒸馏基线：方点，棕色，大小52
    2: ("D",  C_OURS_PLDK, 60,  3, 1.0),   # ← PLDK+MPC：菱形，中蓝，大小60
    3: ("*",  C_OURS,      130, 4, 1.2),   # ← Ours：星形，深蓝，大小130（最突出）
}

# 需要在图中直接打文字标注的方法名（其余方法只在图例中出现）
ANNOTATE = {"No Defense", "DMP", "PLDK", "MPC + KA\n(Ours)"}

# ══════════════════════════════════════════════════════════════════════════════
# ❻  图2 数据（来自 Table 3）
# ══════════════════════════════════════════════════════════════════════════════
methods_t3 = ["FedMD", "FedKD", "Selective-FD", "Ours\n(dist.500)"]

# CIFAR-10 数值
t3_c_test = [79.37, 78.66, 68.98, 64.36]
t3_c_Ab   = [69.25, 73.88, 51.18, 49.62]
t3_c_Aw   = [72.91, 79.17, 54.44, 49.94]

# STL-10 数值
t3_s_test = [43.52, 43.09, 34.89, 49.51]
t3_s_Ab   = [49.85, 49.85, 49.95, 49.85]
t3_s_Aw   = [50.55, 50.42, 51.08, 49.92]

# 图2 隐私子图中相邻 Ab/Aw 两根柱的间距（半宽）
# 增大 BAR_W → 柱子变宽，减小 → 柱子变细
BAR_W = 0.18   # ← 图2 隐私子图每根柱子的宽度（数据坐标单位）

# ══════════════════════════════════════════════════════════════════════════════
# ❼  图3 数据（来自 Table 4）
# ══════════════════════════════════════════════════════════════════════════════
methods_t4 = [
    "PATE",
    "DP-SGD\n(ε=198.5)",
    "DP-SGD\n(ε=50.2)",
    "Hierarchical\nDP",
    "QL-PGD",
    "Ours",
]
# 横轴显示的缩短版方法名（如嫌 Hier.DP 不够清楚可改回 HierarchicalDP）
labels_short4 = [
    "PATE",
    "DP-SGD\n(ε=198.5)",
    "DP-SGD\n(ε=50.2)",
    "Hier.DP",      # ← 可改为 "HierarchicalDP" 等
    "QL-PGD",
    "Ours",
]

# CIFAR-10 数值
t4_c_test = [40.59, 56.59, 53.85, 48.56, 60.99, 64.36]
t4_c_Ab   = [50.01, 50.49, 50.14, 50.99, 50.34, 49.62]

# STL-10 数值
t4_s_test = [26.07, 42.11, 40.61, 34.75, 44.01, 49.51]
t4_s_Ab   = [50.62, 49.42, 49.72, 49.58, 54.44, 49.85]


# ══════════════════════════════════════════════════════════════════════════════
# 辅助函数：横轴标签对齐微调
# ══════════════════════════════════════════════════════════════════════════════
def apply_xtick_label_tuning(ax, tick_positions, labels, tune, fontsize=None):
    ax.set_xticks(tick_positions)
    texts = ax.set_xticklabels(labels, rotation=tune["rotation"],
                               ha=tune["ha"], fontsize=fontsize)
    ax.tick_params(axis="x", pad=tune["pad"])
    for text in texts:
        offset = mtransforms.ScaledTranslation(
            tune["dx"] / 72.0, tune["dy"] / 72.0,
            ax.figure.dpi_scale_trans)
        text.set_transform(text.get_transform() + offset)
    return texts


def apply_special_tick_fontsizes(texts, font_map):
    for text in texts:
        if text.get_text() in font_map:
            text.set_fontsize(font_map[text.get_text()])


# ══════════════════════════════════════════════════════════════════════════════
# ▌图1：隐私-效用权衡散点图
# ══════════════════════════════════════════════════════════════════════════════
def scatter_panel(ax, data, title):
    ax.set_facecolor("white")
    ax.yaxis.grid(True,
                  color="#e0e0e0",   # ← 横向辅助网格线颜色
                  linewidth=0.6,     # ← 网格线粗细
                  zorder=0)
    ax.set_axisbelow(True)

    # random-guess 竖虚线
    ax.axvline(x=50,
               color=C_RANDOM,      # ← 参考线颜色（复用全局 C_RANDOM）
               linestyle="--",      # ← 线型："--"虚线  "-."点划线  ":"点线
               linewidth=1.0,       # ← 参考线粗细
               alpha=0.8,           # ← 透明度（0=全透，1=不透）
               zorder=1)
    ax.text(50.4,
            ax.get_ylim()[0] if ax.get_ylim()[0] > 0 else 37,
            "random\nguess",
            color=C_RANDOM,         # ← 参考文字颜色
            fontsize=6.5,           # ← 参考文字字号
            va="bottom", alpha=0.85)

    for label, test, priv, cat in data:
        mk, col, sz, zo, ew = cat_style[cat]
        ax.scatter(priv, test,
                   marker=mk,
                   color=col,
                   s=sz,
                   edgecolors="white",   # ← 散点边框颜色，"white"使点有描边感
                   linewidths=ew,
                   zorder=zo)

        if label in ANNOTATE:
            # 各标注的偏移量（单位：数据坐标）
            dx, dy = 0.6, 0.8
            if label == "No Defense":
                dx, dy = 0.6, 1.5
            elif label == "DMP":
                dx, dy = 0.6, -2.5
            elif label == "PLDK":
                dx, dy = 0.6, 1.2
            elif "Ours" in label:
                dx, dy = -5.5, 1.8
            clean = label.replace("\n", " ")
            ax.annotate(clean, (priv, test),
                        xytext=(priv + dx, test + dy),
                        fontsize=7.0,           # ← 标注文字字号
                        color="#222222",        # ← 标注文字颜色
                        arrowprops=dict(
                            arrowstyle="-",     # ← 箭头样式："-"纯线段（无箭头）
                            color="#aaaaaa",    # ← 引导线颜色
                            lw=0.6),            # ← 引导线粗细
                        ha="left" if dx > 0 else "right")

    ax.set_xlabel("Priv Acc (Ab) (%)", labelpad=4)
    ax.set_ylabel("Test Acc (%)", labelpad=4)
    ax.set_title(title, pad=5, fontweight="normal")


fig1, axes = plt.subplots(1, 2, figsize=(6.8, 3.0), constrained_layout=True)
#                                ↑宽  ↑高（英寸）← 整体画布尺寸，适合双栏论文

for ax, data, sub in zip(axes,
                         [data_t2_cifar, data_t2_stl],
                         ["(a) CIFAR-10", "(b) STL-10"]):
    tests = [d[1] for d in data]
    ax.set_ylim(min(tests) - 5, max(tests) + 7)   # ← 纵轴上下留白，可调整数字
    ax.set_xlim(46, 82)                            # ← 横轴范围
    scatter_panel(ax, data, sub)

# 图例
legend_handles = [
    Line2D([0], [0], marker="o", color="w",
           markerfacecolor=C_STANDARD,   # ← 传统防御图例颜色（同 C_STANDARD）
           markersize=6, label="Standard defenses"),
    Line2D([0], [0], marker="s", color="w",
           markerfacecolor=C_DISTILL,    # ← 蒸馏基线图例颜色（同 C_DISTILL）
           markersize=6, label="Distillation baselines"),
    Line2D([0], [0], marker="D", color="w",
           markerfacecolor=C_OURS_PLDK,  # ← PLDK+MPC 图例颜色（同 C_OURS_PLDK）
           markersize=6, label="PLDK + MPC"),
    Line2D([0], [0], marker="*", color="w",
           markerfacecolor=C_OURS,       # ← Ours 图例颜色（同 C_OURS）
           markersize=9, label="MPC + KA (Ours)"),
    Line2D([0], [0], linestyle="--",
           color=C_RANDOM,               # ← 参考线图例颜色（同 C_RANDOM）
           linewidth=1, label="Random-guess boundary"),
]
fig1.legend(handles=legend_handles,
            loc="lower center",
            bbox_to_anchor=(0.5, -0.14),   # ← 图例位置：(水平中心, 图下方)
            ncol=3,                         # ← 图例列数
            frameon=True,
            handlelength=1.5,
            columnspacing=1.0)

# ★ 图1 无 suptitle（已移除）

for fmt in ("pdf", "png"):
    fig1.savefig(os.path.join(OUT, f"fig1_tradeoff.{fmt}"),
                 format=fmt, bbox_inches="tight", dpi=300)
print("Figure 1 saved.")
plt.close(fig1)


# ══════════════════════════════════════════════════════════════════════════════
# ▌图2 公用函数
# ══════════════════════════════════════════════════════════════════════════════
def grouped_bars_privacy(ax, x, ab_vals, aw_vals, cols_ab, cols_aw,
                         method_labels, title):
    """隐私子图：每个方法画 Ab / Aw 两根并排柱。"""
    ax.set_facecolor("white")
    ax.yaxis.grid(True, color="#e0e0e0", linewidth=0.6, zorder=0)
    ax.set_axisbelow(True)

    # random-guess 水平参考线
    ax.axhline(50,
               color=C_RANDOM,      # ← 参考线颜色
               linestyle="--",      # ← 线型
               linewidth=0.9,       # ← 线粗
               alpha=0.85, zorder=5)

    offsets = [-0.5 * BAR_W, 0.5 * BAR_W]   # ← Ab 柱偏左，Aw 柱偏右
    for i, (ab, aw, ca, cw) in enumerate(zip(ab_vals, aw_vals, cols_ab, cols_aw)):
        ax.bar(x[i] + offsets[0], ab,
               width=BAR_W,          # ← Ab 柱宽（同全局 BAR_W）
               color=ca,             # ← Ab 柱颜色（来自 bar_cols_Ab）
               edgecolor="white",    # ← 柱子边框颜色
               linewidth=0.4,        # ← 柱子边框粗细
               zorder=3)
        ax.bar(x[i] + offsets[1], aw,
               width=BAR_W,          # ← Aw 柱宽
               color=cw,             # ← Aw 柱颜色（来自 bar_cols_Aw）
               edgecolor="white",
               linewidth=0.4,
               zorder=3)

        # 只给 Ours（最后一根）标数值
        if i == len(ab_vals) - 1:
            ax.text(x[i] + offsets[0] - 0.12, ab + 0.95,
                    f"{ab:.2f}",
                    ha="center", va="bottom",
                    fontsize=6.8,          # ← Ours 数值标注字号
                    color=cols_ab[i],      # ← 标注颜色跟随柱子颜色
                    fontweight="bold")
            ax.text(x[i] + offsets[1] + 0.11, aw + 0.95,
                    f"{aw:.2f}",
                    ha="center", va="bottom",
                    fontsize=6.8,
                    color=cols_aw[i],
                    fontweight="bold")

    apply_xtick_label_tuning(ax, x, method_labels, XTICK_TUNE_FIG2)
    ax.set_ylabel("Priv Acc (%)", labelpad=3)
    ax.set_title(title, pad=5)
    all_vals = list(ab_vals) + list(aw_vals)
    ax.set_ylim(44, max(all_vals) + 8)   # ← 纵轴范围：下限44，上限自动留白
    ax.text(x[-1] + 0.6, 50.4, "Random\nguess",
            color=C_RANDOM,    # ← 参考文字颜色
            fontsize=6.2, va="bottom")


def bar_test(ax, x, vals, cols, method_labels, title, ylabel="Test Acc (%)"):
    """Test Acc 柱状图。"""
    ax.set_facecolor("white")
    ax.yaxis.grid(True, color="#e0e0e0", linewidth=0.6, zorder=0)
    ax.set_axisbelow(True)
    for i, (v, c) in enumerate(zip(vals, cols)):
        ax.bar(x[i], v,
               width=0.5,           # ← 图2 Test Acc 柱宽，想要更宽就调大
               color=c,             # ← 柱子颜色（来自 bar_cols_base）
               edgecolor="white",   # ← 柱子边框颜色
               linewidth=0.4,       # ← 柱子边框粗细
               zorder=3)
        if i == len(vals) - 1:      # 只给 Ours 标数值
            ax.text(x[i], v + 0.6, f"{v:.1f}",
                    ha="center", va="bottom",
                    fontsize=7,        # ← Ours 数值标注字号
                    color=C_OURS)      # ← 标注颜色
    apply_xtick_label_tuning(ax, x, method_labels, XTICK_TUNE_FIG2)
    ax.set_ylabel(ylabel, labelpad=3)
    ax.set_title(title, pad=5)
    ax.set_ylim(0, max(vals) + 12)   # ← 纵轴上方留白，可调整 +12


# ══════════════════════════════════════════════════════════════════════════════
# ▌图2：异构蒸馏基线对比
# ══════════════════════════════════════════════════════════════════════════════
x3_pos     = np.arange(len(methods_t3))
labels_short = ["FedMD", "FedKD", "Sel.-FD", "Ours"]   # ← 横轴缩短显示名

# 共用图例（fig2a / fig2b 两张图用同一套）
leg2_handles = [
    mpatches.Patch(color=bar_cols_Ab[0], label="Priv Acc (Ab)"),  # ← 图例色块颜色
    mpatches.Patch(color=bar_cols_Aw[0], label="Priv Acc (Aw)"),
    mpatches.Patch(color=C_OURS,         label="Ours"),
    Line2D([0], [0], linestyle="--",
           color=C_RANDOM,    # ← 图例中参考线颜色
           linewidth=1, label="Random guess (50%)"),
]

# ── Figure 2a：CIFAR-10 ── 1×2 ───────────────────────────────────────────────
fig2a, ax2a = plt.subplots(1, 2,
                            figsize=(7.0, 3.0),   # ← 画布尺寸（宽×高，英寸）
                            constrained_layout=True)

bar_test(ax2a[0], x3_pos, t3_c_test, bar_cols_base,
         labels_short, "(a) Test Acc (%)")

grouped_bars_privacy(ax2a[1], x3_pos,
                     t3_c_Ab, t3_c_Aw,
                     bar_cols_Ab, bar_cols_Aw,
                     labels_short, "(b) Priv Acc (%)")

fig2a.legend(handles=leg2_handles,
             loc="lower center",
             bbox_to_anchor=(0.5, -0.18),   # ← 图例纵向位置，越负越靠下
             ncol=4,                         # ← 图例列数
             frameon=True, handlelength=1.4)
# ★ 图2a 无 suptitle（已移除）

for fmt in ("pdf", "png"):
    fig2a.savefig(os.path.join(OUT, f"fig2_cifar10.{fmt}"),
                  format=fmt, bbox_inches="tight", dpi=300)
print("Figure 2a (CIFAR-10) saved.")
plt.close(fig2a)

# ── Figure 2b：STL-10 ── 1×2 ─────────────────────────────────────────────────
fig2b, ax2b = plt.subplots(1, 2,
                            figsize=(7.0, 3.0),   # ← 画布尺寸
                            constrained_layout=True)

bar_test(ax2b[0], x3_pos, t3_s_test, bar_cols_base,
         labels_short, "(a) Test Acc (%)")

grouped_bars_privacy(ax2b[1], x3_pos,
                     t3_s_Ab, t3_s_Aw,
                     bar_cols_Ab, bar_cols_Aw,
                     labels_short, "(b) Priv Acc (%)")

fig2b.legend(handles=leg2_handles,
             loc="lower center",
             bbox_to_anchor=(0.5, -0.18),
             ncol=4, frameon=True, handlelength=1.4)
# ★ 图2b 无 suptitle（已移除）

for fmt in ("pdf", "png"):
    fig2b.savefig(os.path.join(OUT, f"fig2_stl10.{fmt}"),
                  format=fmt, bbox_inches="tight", dpi=300)
print("Figure 2b (STL-10) saved.")
plt.close(fig2b)


# ══════════════════════════════════════════════════════════════════════════════
# ▌图3 公用函数
# ══════════════════════════════════════════════════════════════════════════════
x4 = np.arange(len(methods_t4))

def bar4_test(ax, x, vals, title):
    """图3 Test Acc 柱状图。"""
    ax.set_facecolor("white")
    ax.yaxis.grid(True, color="#e0e0e0", linewidth=0.6, zorder=0)
    ax.set_axisbelow(True)
    for i, (v, c) in enumerate(zip(vals, RAMP)):
        ax.bar(x[i], v,
               width=0.55,          # ← 图3 柱宽，想要更宽就调大
               color=c,             # ← 柱子颜色（来自 RAMP）
               edgecolor="white",   # ← 柱子边框颜色
               linewidth=0.4,       # ← 柱子边框粗细
               zorder=3)
    # 只给 Ours 标数值
    ax.text(x[-1], vals[-1] + 0.8, f"{vals[-1]:.2f}",
            ha="center", va="bottom",
            fontsize=7,             # ← Ours 数值字号
            color=C_OURS,           # ← Ours 数值颜色
            fontweight="bold")
    texts = apply_xtick_label_tuning(ax, x, labels_short4, XTICK_TUNE_FIG3,
                                     fontsize=7.5)
    apply_special_tick_fontsizes(texts, FIG3_SPECIAL_TICK_FONTS)
    ax.set_ylabel("Test Acc (%)", labelpad=3)
    ax.set_title(title, pad=5)
    ax.set_ylim(0, max(vals) + 14)   # ← 纵轴上方留白


def bar4_priv(ax, x, vals, title):
    """图3 Priv Acc (Ab) 柱状图。"""
    ax.set_facecolor("white")
    ax.yaxis.grid(True, color="#e0e0e0", linewidth=0.6, zorder=0)
    ax.set_axisbelow(True)

    # random-guess 水平参考线
    ax.axhline(50,
               color=C_RANDOM,      # ← 参考线颜色
               linestyle="--",      # ← 线型
               linewidth=0.9,       # ← 线粗
               alpha=0.85, zorder=5)

    for i, (v, c) in enumerate(zip(vals, RAMP)):
        ax.bar(x[i], v,
               width=0.55,          # ← 图3 隐私子图柱宽
               color=c,             # ← 柱子颜色（来自 RAMP）
               edgecolor="white",   # ← 柱子边框颜色
               linewidth=0.4,
               zorder=3)
        if i == len(vals) - 1:     # 只给 Ours 标数值
            ax.text(x[i], v + 0.35, f"{v:.2f}",
                    ha="center", va="bottom",
                    fontsize=6.8,    # ← Ours 数值字号
                    color=C_OURS,    # ← Ours 数值颜色
                    fontweight="bold")

    texts = apply_xtick_label_tuning(ax, x, labels_short4, XTICK_TUNE_FIG3,
                                     fontsize=7.5)
    apply_special_tick_fontsizes(texts, FIG3_SPECIAL_TICK_FONTS)
    ax.set_ylabel("Priv Acc (Ab) (%)", labelpad=3)
    ax.set_title(title, pad=5)
    mn, mx = min(vals), max(vals)
    ax.set_ylim(mn - 3, mx + 6)     # ← 纵轴上下留白
    ax.text(x[-1] + 0.55, 50.1, "Random guess",
            color=C_RANDOM,          # ← 参考文字颜色
            fontsize=6.2, va="bottom")


# ══════════════════════════════════════════════════════════════════════════════
# ▌图3：跨范式 DP / 正则化基线对比
# ══════════════════════════════════════════════════════════════════════════════

# 共用图例（fig3a / fig3b 两张图用同一套）
leg3_handles = [
    mpatches.Patch(color=RAMP[0],  label="DP / Regularization baselines"),  # ← 图例色块颜色
    mpatches.Patch(color=C_OURS,   label="Ours (Secure Distillation)"),
    Line2D([0], [0], linestyle="--",
           color=C_RANDOM,     # ← 图例中参考线颜色
           linewidth=1, label="Random guess (50%)"),
]

# ── Figure 3a：CIFAR-10 ── 1×2 ───────────────────────────────────────────────
fig3a, ax3a = plt.subplots(1, 2,
                            figsize=(7.2, 3.0),   # ← 画布尺寸（宽×高，英寸）
                            constrained_layout=True)

bar4_test(ax3a[0], x4, t4_c_test, "(a) Test Acc (%)")
bar4_priv(ax3a[1], x4, t4_c_Ab,   "(b) Priv Acc (Ab) (%)")

fig3a.legend(handles=leg3_handles,
             loc="lower center",
             bbox_to_anchor=(0.5, -0.14),   # ← 图例纵向位置
             ncol=3, frameon=True, handlelength=1.4)
# ★ 图3a 无 suptitle（已移除）

for fmt in ("pdf", "png"):
    fig3a.savefig(os.path.join(OUT, f"fig3_cifar10.{fmt}"),
                  format=fmt, bbox_inches="tight", dpi=300)
print("Figure 3a (CIFAR-10) saved.")
plt.close(fig3a)

# ── Figure 3b：STL-10 ── 1×2 ─────────────────────────────────────────────────
fig3b, ax3b = plt.subplots(1, 2,
                            figsize=(7.2, 3.0),   # ← 画布尺寸
                            constrained_layout=True)

bar4_test(ax3b[0], x4, t4_s_test, "(a) Test Acc (%)")
bar4_priv(ax3b[1], x4, t4_s_Ab,   "(b) Priv Acc (Ab) (%)")

fig3b.legend(handles=leg3_handles,
             loc="lower center",
             bbox_to_anchor=(0.5, -0.14),
             ncol=3, frameon=True, handlelength=1.4)
# ★ 图3b 无 suptitle（已移除）

for fmt in ("pdf", "png"):
    fig3b.savefig(os.path.join(OUT, f"fig3_stl10.{fmt}"),
                  format=fmt, bbox_inches="tight", dpi=300)
print("Figure 3b (STL-10) saved.")
plt.close(fig3b)

print("All figures saved to", OUT)