"""
visualize_mpc.py
================
可视化 PLDK + NssMPC 数据管线的三个阶段：

  图1  蒸馏数据网格（10类 × 10张，对标论文 Fig.3(b)）
  图2  秘密分享视角（原图 / Party0 / Party1，模拟两家医院的视图）
  图3  MPC重构对比（原图 vs 重构图，两行）

只需修改 ACTIVE_DATASET 即可切换数据集。
依赖：torch, torchvision, matplotlib, numpy
"""

import os
import torch
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from torchvision import transforms

# ╔══════════════════════════════════════════════════════════╗
# ║               用户配置区（只需改这里）                    ║
# ╚══════════════════════════════════════════════════════════╝

# 切换数据集：'cifar10' 或 'stl10'
ACTIVE_DATASET = 'stl10'

# 数据集参数库
DATASET_CONFIGS = {
    'cifar10': {
        'mean'        : (0.4914, 0.4822, 0.4465),
        'std'         : (0.2023, 0.1994, 0.2010),
        'images_path' : 'images_best_cifar10.pt',
        'labels_path' : None,          # None 则根据 MTT 排列推断
        'ipc'         : 50,            # 每类蒸馏图片数
        'num_classes' : 10,
        'distill_res' : 32,
        'class_names' : [
            'airplane', 'automobile', 'bird', 'cat', 'deer',
            'dog', 'frog', 'horse', 'ship', 'truck',
        ],
        'tag'         : 'CIFAR-10',
    },
    'stl10': {
        'mean'        : (0.4467, 0.4398, 0.4066),
        'std'         : (0.2603, 0.2566, 0.2713),
        'images_path' : 'images_best_stl10.pt',
        'labels_path' : None,
        'ipc'         : 50,
        'num_classes' : 10,
        'distill_res' : 32,
        'class_names' : [
            'airplane', 'bird', 'car', 'cat', 'deer',
            'dog', 'horse', 'monkey', 'ship', 'truck',
        ],
        'tag'         : 'STL-10',
    },
}

# 可视化全局参数
COLS_PER_CLASS    = 10      # 图1每类显示列数
N_MPC_SHOW        = 8       # 图2、图3显示的图片数量
FIXED_POINT_SCALE = 2**16   # 定点编码精度（与 3pc_generic.py 保持一致）
OUTPUT_DIR        = 'newComparisonFigSolo'   # 输出目录

# ┌─────────────────────────────────────────────────────────┐
# │  ★ [可手动调整] 全局输出分辨率（DPI）                    │
# │  论文投稿建议 300；预览用 180 可加快速度                   │
# │  作用范围：图1、图2、图3 全部图片                         │
# └─────────────────────────────────────────────────────────┘
DPI = 300    # ← 已改为 300 dpi（论文标准）


# ══════════════════════════════════════════════════════════
# MPC 辅助函数（完全复现 3pc_generic.py 的加密/解密逻辑）
# ══════════════════════════════════════════════════════════

def float_to_ring(t: torch.Tensor) -> torch.Tensor:
    """浮点数 → 定点整数编码（×2^16，取整，转 int64）"""
    return (t * FIXED_POINT_SCALE).round().to(torch.int64)


def additive_secret_share(ring: torch.Tensor):
    """
    加法秘密共享（2-out-of-2，Z_{2^64} 整数环）
    share0：均匀随机 int64
    share1 = ring - share0（mod 2^64，int64 自动 wrapping）
    单独一份在信息论意义上与均匀随机无区别。
    """
    share0 = torch.randint(
        low  = -(2**63),
        high =   2**63 - 1,
        size = ring.shape,
        dtype= torch.int64,
    )
    share1 = ring - share0   # int64 自动 mod 2^64
    return share0, share1


def ring_to_float(s0: torch.Tensor, s1: torch.Tensor) -> torch.Tensor:
    """两份 share 相加后除以 2^16，还原浮点数（对应 3pc_generic ring_to_float）"""
    return (s0 + s1).to(torch.float32) / FIXED_POINT_SCALE


# ══════════════════════════════════════════════════════════
# 图像处理工具
# ══════════════════════════════════════════════════════════

def denormalize(imgs: torch.Tensor, cfg: dict) -> torch.Tensor:
    """反归一化：normalized tensor → [0, 1] 像素范围"""
    mean = torch.tensor(cfg['mean'], dtype=torch.float32).view(3, 1, 1)
    std  = torch.tensor(cfg['std'],  dtype=torch.float32).view(3, 1, 1)
    return (imgs * std + mean).clamp(0.0, 1.0)


def to_hwc(t: torch.Tensor) -> np.ndarray:
    """[3, H, W] float tensor → (H, W, 3) numpy 数组"""
    return t.permute(1, 2, 0).numpy().astype(np.float32)


def share_to_display(share: torch.Tensor) -> torch.Tensor:
    """
    将 int64 份额映射到 [0,1] 供显示。
    逐图 min-max 归一化，展现份额的噪声纹理。
    """
    s  = share.to(torch.float64)
    mn = s.flatten(1).min(1).values.view(-1, 1, 1, 1)
    mx = s.flatten(1).max(1).values.view(-1, 1, 1, 1)
    return ((s - mn) / (mx - mn + 1.0)).clamp(0.0, 1.0).to(torch.float32)


def save_figure_multi_format(fig, output_dir: str, base_name: str):
    """
    统一导出论文图：同时保存高分辨率 PNG 和 PDF。
    PNG 保持 DPI 控制；PDF 使用矢量格式，便于论文排版。
    """
    os.makedirs(output_dir, exist_ok=True)

    saved_paths = []
    for fmt in ("png", "pdf"):
        out = os.path.join(output_dir, f"{base_name}.{fmt}")
        save_kwargs = {
            "format": fmt,
            "bbox_inches": "tight",
            "facecolor": "white",
        }
        if fmt == "png":
            save_kwargs["dpi"] = DPI
        fig.savefig(out, **save_kwargs)
        saved_paths.append(out)

    return saved_paths


# ══════════════════════════════════════════════════════════
# 数据加载
# ══════════════════════════════════════════════════════════

def load_distilled_data(cfg: dict):
    """
    加载蒸馏图像文件，必要时补归一化，并推断/加载类别标签。
    返回：images_norm [N,3,H,W]，labels [N]（均在 CPU）
    """
    path = cfg['images_path']
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"找不到蒸馏数据文件: '{path}'\n"
            f"请在 DATASET_CONFIGS['{ACTIVE_DATASET}']['images_path'] 中设置正确路径。"
        )

    imgs = torch.load(path, map_location='cpu')
    if imgs.dtype != torch.float32:
        imgs = imgs.float()

    print(f"  加载文件 : {path}")
    print(f"  数据形状 : {imgs.shape}")
    print(f"  值域     : [{imgs.min():.4f}, {imgs.max():.4f}]")

    # 若数据在 [0,1] 范围内则尚未归一化
    if imgs.min() >= 0.0 and imgs.max() <= 1.0:
        print("  检测到未归一化数据，应用数据集归一化...")
        imgs = transforms.Normalize(cfg['mean'], cfg['std'])(imgs)
        print(f"  归一化后值域 : [{imgs.min():.4f}, {imgs.max():.4f}]")
    else:
        print("  数据已归一化，跳过。")

    # 加载或推断标签
    lbl_path = cfg.get('labels_path')
    if lbl_path and os.path.exists(lbl_path):
        labels = torch.load(lbl_path, map_location='cpu').long()
        print(f"  标签来源 : {lbl_path}")
    else:
        # MTT 默认布局：[class0×ipc, class1×ipc, ...]
        ipc = cfg['ipc']
        nc  = cfg['num_classes']
        labels = torch.arange(nc).repeat_interleave(ipc)
        print(f"  标签推断 : MTT 默认排列（ipc={ipc}, classes={nc}）")

    return imgs, labels


# ══════════════════════════════════════════════════════════
# 图1：蒸馏数据网格（对标论文 Fig.3(b)）
# ══════════════════════════════════════════════════════════

def make_figure1(images_norm, labels, cfg, show_labels=True, class_order=None):
    """
    绘制 num_classes × COLS_PER_CLASS 的蒸馏数据网格。
    每行一类，左侧可选显示类名，图片间距紧凑，
    对标 PLDK 论文 Fig.3(b) 风格。

    参数
    ----
    show_labels : bool
        True  → 左侧渲染类名标签（CIFAR-10 图使用）
        False → 不渲染类名标签，图片区左移顶格（STL-10 独立图使用）
    class_order : list[str] | None
        若提供，则按给定类别名称顺序收集并渲染各行；
        否则按 cfg['class_names'] 的原始顺序输出。
    """
    nc    = cfg['num_classes']
    cols  = COLS_PER_CLASS
    names = class_order if class_order is not None else cfg['class_names']
    tag   = cfg['tag']
    res   = images_norm.shape[-1]

    # 按类别收集 cols 张图片
    name_to_idx = {name: i for i, name in enumerate(cfg['class_names'])}
    class_indices = [name_to_idx[name] for name in names]
    grid_imgs = []
    for c in class_indices:
        idx  = (labels == c).nonzero(as_tuple=True)[0]
        sel_idx = torch.randperm(len(idx))[:cols] if len(idx) >= cols \
                  else torch.arange(len(idx))
        sel  = denormalize(images_norm[idx[sel_idx]], cfg)
        row  = [to_hwc(sel[i]) for i in range(len(sel))]
        # 图片不足时用灰色填充
        blank = np.full((res, res, 3), 0.88, dtype=np.float32)
        row  += [blank] * (cols - len(row))
        grid_imgs.append(row)

    # ┌─────────────────────────────────────────────────────┐
    # │  ★ [可手动调整] 图1 布局尺寸参数                     │
    # │  LABEL_W : 左侧类名列的宽度（英寸）                  │
    # │  CELL    : 每张图片单元格的尺寸（英寸），影响图片大小  │
    # │  TOP_PAD : 顶部留白高度（英寸）；标题已移除故缩小      │
    # │  BOT_PAD : 底部留白高度（英寸）                      │
    # │  IMG_GAP : 图片之间的间隙（占单元格的比例，0~1）       │
    # │  fig_w/fig_h 由上方参数自动计算，无需手动修改          │
    # └─────────────────────────────────────────────────────┘
    LABEL_W  = 0.80    # ← [可手动调整] 类名列宽度（英寸）；show_labels=False 时自动置0
    CELL     = 0.33    # ← [可手动调整] 图片单元格尺寸（英寸），调大整张图变大
    TOP_PAD  = 0.08    # ← [可手动调整] 顶部留白（英寸）；标题已移除故缩小
    BOT_PAD  = 0.12    # ← [可手动调整] 底部留白（英寸）
    IMG_GAP  = 0.012   # ← [可手动调整] 图片间距（0=无间距，0.05=明显间距）

    # show_labels=False 时不保留类名列宽度
    effective_label_w = LABEL_W if show_labels else 0.0

    # 图片总尺寸（由上方参数自动计算，一般无需改动）
    fig_w = effective_label_w + cols * CELL + 0.12
    fig_h = TOP_PAD + nc * CELL + BOT_PAD

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor='white')

    # ★ 图1 标题已移除（不渲染 "Distilled Dataset — {tag}" 标题）
    # 如需恢复，取消下方注释并将 TOP_PAD 改回 0.30
    # fig.text(
    #     0.6,
    #     1.0 - 0.02 / fig_h,
    #     f"Distilled Dataset — {tag}",
    #     ha='center', va='top',
    #     fontsize=11,
    #     fontweight='bold',
    #     color='#1A1A2E',
    # )

    # 计算坐标系比例（由布局参数自动推导，无需改动）
    lf = effective_label_w / fig_w
    tf = TOP_PAD / fig_h
    plot_h = 1.0 - tf - BOT_PAD / fig_h
    row_h  = plot_h / nc
    col_w  = (1.0 - lf - 0.01) / cols

    LABEL_Y_SHIFT = -0.035  # ← [可手动调整] 标签轻微下移，修正视觉上偏上的问题

    for row in range(nc):
        # ┌───────────────────────────────────────────────────┐
        # │  ★ [可手动调整] 图1 类名标签样式                  │
        # │  fontsize   : 类名字号                            │
        # │  color      : 类名颜色                            │
        # │  fontweight : 'normal' 不加粗 / 'bold' 加粗       │
        # │  lf-0.008   : 类名与图片区域的水平间距，           │
        # │               负数越大间距越宽（← [可手动调整]）   │
        # └───────────────────────────────────────────────────┘
        if show_labels:
            # 与图像行中心对齐，并做一个轻微下移的视觉校正，
            # 避免 fig.text 在粗体标签下看起来略偏上。
            y_center = 1.0 - tf - (row + 0.5) * row_h + LABEL_Y_SHIFT * row_h
            fig.text(
                lf - 0.008,           # ← [可手动调整] 类名到图片区的水平偏移（增大=离图片更远）
                y_center,
                names[row],
                ha='right', va='center',
                fontsize=7.5,         # ← [可手动调整] 类名字号（pt）
                color='#222222',      # ← [可手动调整] 类名颜色
                fontweight='bold',    # ← [可手动调整] 'normal' 不加粗 / 'bold' 加粗
            )

        for col in range(cols):
            l = lf + col * col_w + col_w * IMG_GAP / 2
            b = 1.0 - tf - (row + 1) * row_h + row_h * IMG_GAP / 2
            w = col_w * (1 - IMG_GAP)
            h = row_h * (1 - IMG_GAP)

            ax = fig.add_axes([l, b, w, h])
            ax.imshow(grid_imgs[row][col], interpolation='nearest')
            ax.set_xticks([]); ax.set_yticks([])
            # ┌─────────────────────────────────────────────────┐
            # │  ★ [可手动调整] 图1 图片边框样式                │
            # │  set_edgecolor : 边框颜色                       │
            # │  set_linewidth : 边框粗细（0=无边框）            │
            # └─────────────────────────────────────────────────┘
            for sp in ax.spines.values():
                sp.set_edgecolor('#BBBBBB')  # ← [可手动调整] 边框颜色
                sp.set_linewidth(0.3)        # ← [可手动调整] 边框粗细（pt）

    # 类名列与图片区分隔线（取消注释可显示）
    # fig.add_artist(plt.Line2D(
    #     [lf - 0.004, lf - 0.004],
    #     [BOT_PAD / fig_h, 1.0 - tf + 0.01],
    #     transform=fig.transFigure,
    #     color='#CCCCCC', linewidth=0.6,
    # ))

    # ┌─────────────────────────────────────────────────────────┐
    # │  ★ [可手动调整] 图1 输出设置                            │
    # │  dpi         : 输出分辨率，已统一使用全局 DPI=300        │
    # │  bbox_inches : 'tight' 自动裁白边，改为 None 保留原始边距 │
    # └─────────────────────────────────────────────────────────┘
    base_name = f'figure1_distilled_{tag.lower().replace("-","")}'
    saved_paths = save_figure_multi_format(fig, OUTPUT_DIR, base_name)
    plt.close(fig)
    for out in saved_paths:
        print(f"  已保存 → {out}")


# ══════════════════════════════════════════════════════════
# 图1 方案B：CIFAR-10 与 STL-10 并排合并图（中间留白分隔）
# ══════════════════════════════════════════════════════════

def make_figure1_combined(
    cifar_norm, cifar_labels, cifar_cfg,
    stl_norm,   stl_labels,   stl_cfg,
):
    """
    将 CIFAR-10（左）和 STL-10（右）拼入同一张画布，
    中间用空白列隔开。
    类名标签只渲染在 CIFAR-10 一侧（左侧）；STL-10 一侧不显示类名。

    布局示意（figure 坐标系，x 从左到右）：
      [类名列] [CIFAR-10 图像区] [间隙] [STL-10 图像区]

    ┌─────────────────────────────────────────────────────────┐
    │  ★ [可手动调整] 合并图布局参数                           │
    │  CELL      : 每张图片单元格尺寸（英寸）                  │
    │  LABEL_W   : 左侧类名列宽度（英寸）                      │
    │  GAP_W     : 两个数据集之间的间隙宽度（英寸）             │
    │              增大 = 间距更宽，建议 0.3 ~ 0.8             │
    │  TOP_PAD   : 顶部留白（英寸）                            │
    │  BOT_PAD   : 底部留白（英寸）                            │
    │  IMG_GAP   : 图片之间的间距比例（同单图）                 │
    └─────────────────────────────────────────────────────────┘
    """
    CELL    = 0.33    # ← [可手动调整] 图片单元格尺寸（英寸）
    LABEL_W = 0.80    # ← [可手动调整] 左侧类名列宽度（英寸）
    GAP_W   = 0.2    # ← [可手动调整] 两数据集间隙宽度（英寸），增大=间距更宽
    TOP_PAD = 0.08    # ← [可手动调整] 顶部留白（英寸）
    BOT_PAD = 0.22    # ← [可手动调整] 底部留白（英寸）；需容纳下方数据集名称
    IMG_GAP = 0.012   # ← [可手动调整] 图片间距比例
    DATASET_LABEL_Y = 0.42   # ← [可手动调整] 数据集标签在底部留白中的相对高度（0~1）
    DATASET_LABEL_FS = 10.5  # ← [可手动调整] 数据集标签字号（pt）

    cols = COLS_PER_CLASS
    nc   = cifar_cfg['num_classes']   # 两个数据集均为 10 类
    res  = cifar_norm.shape[-1]

    # 在 combined 图中，让右侧 STL-10 按左侧 CIFAR-10 的语义顺序渲染。
    # 说明：
    #   - 共有类别直接按同名匹配
    #   - CIFAR-10 的 automobile 对应 STL-10 的 car
    #   - CIFAR-10 的 frog 在 STL-10 中不存在，这里用 monkey 占位，
    #     这样整体行顺序仍然跟随左侧 CIFAR-10
    stl_alias_for_cifar = {
        'automobile': 'car',
        'frog': 'monkey',
    }

    # ── 收集两侧图像 ─────────────────────────────────────────
    def collect_grid(images_norm, labels, cfg, class_order=None):
        grid = []
        if class_order is None:
            class_indices = list(range(nc))
        else:
            name_to_idx = {name: i for i, name in enumerate(cfg['class_names'])}
            class_indices = [name_to_idx[name] for name in class_order]

        for c in class_indices:
            idx = (labels == c).nonzero(as_tuple=True)[0]
            sel_idx = torch.randperm(len(idx))[:cols] if len(idx) >= cols \
                      else torch.arange(len(idx))
            sel  = denormalize(images_norm[idx[sel_idx]], cfg)
            row  = [to_hwc(sel[i]) for i in range(len(sel))]
            blank = np.full((res, res, 3), 0.88, dtype=np.float32)
            row  += [blank] * (cols - len(row))
            grid.append(row)
        return grid

    cifar_grid = collect_grid(cifar_norm, cifar_labels, cifar_cfg)
    stl_order_for_combined = [
        stl_alias_for_cifar.get(name, name)
        for name in cifar_cfg['class_names']
    ]
    stl_grid   = collect_grid(stl_norm, stl_labels, stl_cfg, class_order=stl_order_for_combined)

    # ── 计算画布尺寸 ─────────────────────────────────────────
    # 宽度：类名列 + CIFAR图像区 + 间隙 + STL图像区 + 右边距
    fig_w = LABEL_W + cols * CELL + GAP_W + cols * CELL + 0.12
    fig_h = TOP_PAD + nc * CELL + BOT_PAD

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor='white')

    # ── 坐标比例（figure 坐标系，范围 0~1）──────────────────
    lf      = LABEL_W / fig_w                 # 类名列右边界（= 图像区左边界）
    tf      = TOP_PAD / fig_h                 # 图像区顶部边界
    plot_h  = 1.0 - tf - BOT_PAD / fig_h
    row_h   = plot_h / nc

    # 两个数据集各自的列宽（归一化）
    img_area_w  = cols * CELL / fig_w         # 单侧图像区宽度（归一化）
    col_w_norm  = img_area_w / cols           # 单个图片列宽（归一化）
    gap_norm    = GAP_W / fig_w               # 间隙宽度（归一化）

    # STL-10 图像区左边界
    stl_left = lf + img_area_w + gap_norm

    LABEL_Y_SHIFT = -0.035  # ← [可手动调整] 标签轻微下移（与单图保持一致）

    for row in range(nc):
        y_center = 1.0 - tf - (row + 0.5) * row_h + LABEL_Y_SHIFT * row_h

        # ── 左侧类名标签（仅 CIFAR-10 侧渲染）────────────────
        fig.text(
            lf - 0.008,           # ← [可手动调整] 类名到图片区水平偏移
            y_center,
            cifar_cfg['class_names'][row],
            ha='right', va='center',
            fontsize=7.5,         # ← [可手动调整] 类名字号（pt）
            color='#222222',      # ← [可手动调整] 类名颜色
            fontweight='bold',    # ← [可手动调整] 字重
        )

        # ── CIFAR-10 图像（左侧）────────────────────────────
        for col in range(cols):
            l = lf    + col * col_w_norm + col_w_norm * IMG_GAP / 2
            b = 1.0 - tf - (row + 1) * row_h + row_h * IMG_GAP / 2
            w = col_w_norm * (1 - IMG_GAP)
            h = row_h      * (1 - IMG_GAP)
            ax = fig.add_axes([l, b, w, h])
            ax.imshow(cifar_grid[row][col], interpolation='nearest')
            ax.set_xticks([]); ax.set_yticks([])
            for sp in ax.spines.values():
                sp.set_edgecolor('#BBBBBB')  # ← [可手动调整] 边框颜色
                sp.set_linewidth(0.3)        # ← [可手动调整] 边框粗细（pt）

        # ── STL-10 图像（右侧，无类名标签）─────────────────
        for col in range(cols):
            l = stl_left + col * col_w_norm + col_w_norm * IMG_GAP / 2
            b = 1.0 - tf - (row + 1) * row_h + row_h * IMG_GAP / 2
            w = col_w_norm * (1 - IMG_GAP)
            h = row_h      * (1 - IMG_GAP)
            ax = fig.add_axes([l, b, w, h])
            ax.imshow(stl_grid[row][col], interpolation='nearest')
            ax.set_xticks([]); ax.set_yticks([])
            for sp in ax.spines.values():
                sp.set_edgecolor('#BBBBBB')  # ← [可手动调整] 边框颜色
                sp.set_linewidth(0.3)        # ← [可手动调整] 边框粗细（pt）

    # ┌─────────────────────────────────────────────────────────┐
    # │  ★ [可手动调整] 合并图底部数据集名称                    │
    # │  CIFAR-10 与 STL-10 会分别显示在各自图像区域正下方      │
    # │  DATASET_LABEL_Y  : 在底部留白中的纵向位置（0~1）       │
    # │  DATASET_LABEL_FS : 标签字号                            │
    # └─────────────────────────────────────────────────────────┘
    dataset_label_y = (BOT_PAD / fig_h) * DATASET_LABEL_Y
    cifar_center_x = lf + img_area_w / 2
    stl_center_x = stl_left + img_area_w / 2

    fig.text(
        cifar_center_x,
        dataset_label_y,
        "CIFAR-10",
        ha='center', va='center',
        fontsize=DATASET_LABEL_FS,
        color='#222222',
        fontweight='bold',
    )
    fig.text(
        stl_center_x,
        dataset_label_y,
        "STL-10",
        ha='center', va='center',
        fontsize=DATASET_LABEL_FS,
        color='#222222',
        fontweight='bold',
    )

    # ┌─────────────────────────────────────────────────────────┐
    # │  ★ [可手动调整] 合并图输出设置                           │
    # └─────────────────────────────────────────────────────────┘
    base_name = 'figure1_distilled_combined'
    saved_paths = save_figure_multi_format(fig, OUTPUT_DIR, base_name)
    plt.close(fig)
    for out in saved_paths:
        print(f"  已保存 → {out}")


# ══════════════════════════════════════════════════════════
# 图2：秘密分享视角（原图 / Party 0 / Party 1）
# ══════════════════════════════════════════════════════════

def make_figure2(images_norm, share0, share1, cfg):
    """
    三行布局：
      第1行 原始蒸馏图像
      第2行 Hospital A (Party 0) 持有的份额 → 呈随机噪声
      第3行 Hospital B (Party 1) 持有的份额 → 呈随机噪声
    不显示任何坐标轴刻度/表格，不显示直方图面板。
    """
    tag = cfg['tag']
    n   = min(N_MPC_SHOW, len(images_norm))

    # 准备三行数据
    orig_01   = denormalize(images_norm[:n], cfg)
    share0_01 = share_to_display(share0[:n])
    share1_01 = share_to_display(share1[:n])

    row_data   = [orig_01, share0_01, share1_01]
    row_labels = [
        'Original(Distilled)',
        'Client A (Party 0)',
        'Client B (Party 1)',
    ]

    # ┌─────────────────────────────────────────────────────┐
    # │  ★ [可手动调整] 图2 布局尺寸参数                     │
    # │  CELL    : 每张图片单元格的尺寸（英寸）               │
    # │  LABEL_W : 左侧行标签列宽度（英寸）                  │
    # │  TOP_PAD : 顶部标题区预留高度（英寸）                 │
    # │  BOT_PAD : 底部留白高度（英寸）                      │
    # │  fig_w/fig_h 由上方参数自动计算                       │
    # └─────────────────────────────────────────────────────┘
    CELL     = 1.05    # ← [可手动调整] 图片单元格尺寸（英寸）
    LABEL_W  = 1.45    # ← [可手动调整] 行标签列宽度（英寸），标签过长时增大
    TOP_PAD  = 0.08    # ← [可手动调整] 顶部留白（英寸）；标题已移除故缩小
    BOT_PAD  = 0.15    # ← [可手动调整] 底部留白（英寸）

    fig_w = LABEL_W + n * CELL + 0.15
    fig_h = TOP_PAD + 3 * CELL + BOT_PAD

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor='white')

    # ★ 图2 标题已移除（不渲染 "Additive Secret Share…" 标题）
    # 如需恢复，取消下方注释并将 TOP_PAD 改回 0.30
    # fig.text(
    #     0.50,
    #     1.0 - 0.02 / (fig_h+1),
    #     f"Additive Secret Share: Client A & B Views  [{tag}]",
    #     ha='center', va='top',
    #     fontsize=10,
    #     fontweight='bold',
    #     color='#1A1A2E',
    # )

    # 布局比例（由尺寸参数自动推导）
    lf     = LABEL_W / fig_w
    tf     = TOP_PAD / fig_h
    row_h  = (1.0 - tf - BOT_PAD / fig_h) / 3
    col_w  = (1.0 - lf - 0.01) / n
    GAP    = 0.012   # ← [可手动调整] 图片间距比例（同图1的 IMG_GAP）

    for row in range(3):
        # ┌───────────────────────────────────────────────────┐
        # │  ★ [可手动调整] 图2 行标签样式                    │
        # │  fontsize  : 行标签字号                           │
        # │  color     : 行标签颜色                           │
        # │  lf-0.010  : 行标签到图片区的水平偏移             │
        # └───────────────────────────────────────────────────┘
        y_center = 1.0 - tf - (row + 0.5) * row_h
        fig.text(
            lf - 0.010,       # ← [可手动调整] 行标签到图片区水平偏移（增大=离图片更远）
            y_center,
            row_labels[row],
            ha='right', va='center',
            fontweight='bold',  # ← [可手动调整] 'normal' 不加粗 / 'bold' 加粗
            fontsize=8.5,     # ← [可手动调整] 行标签字号（pt）
            color='#1A1A2E',  # ← [可手动调整] 行标签颜色
        )

        for col in range(n):
            l = lf + col * col_w + col_w * GAP / 2
            b = 1.0 - tf - (row + 1) * row_h + row_h * GAP / 2
            w = col_w * (1 - GAP)
            h = row_h * (1 - GAP)

            ax = fig.add_axes([l, b, w, h])
            ax.imshow(to_hwc(row_data[row][col]), interpolation='nearest')
            ax.set_xticks([]); ax.set_yticks([])
            ax.tick_params(left=False, bottom=False,
                           labelleft=False, labelbottom=False)
            # ┌─────────────────────────────────────────────────┐
            # │  ★ [可手动调整] 图2 图片边框样式                │
            # └─────────────────────────────────────────────────┘
            for sp in ax.spines.values():
                sp.set_edgecolor('#BBBBBB')  # ← [可手动调整] 边框颜色
                sp.set_linewidth(0.3)        # ← [可手动调整] 边框粗细（pt，0=无边框）

    # 底部注释文字（取消注释可显示）
    # fig.text(
    #     0.5, BOT_PAD / fig_h - 0.01,
    #     "Each share is uniformly random — "
    #     "information-theoretically secure without the other share",
    #     ha='center', va='bottom',
    #     fontsize=7.5, color='#666666', style='italic',
    # )

    # ┌─────────────────────────────────────────────────────────┐
    # │  ★ [可手动调整] 图2 输出设置                            │
    # └─────────────────────────────────────────────────────────┘
    base_name = f'figure2_secret_share_{tag.lower().replace("-","")}'
    saved_paths = save_figure_multi_format(fig, OUTPUT_DIR, base_name)
    plt.close(fig)
    for out in saved_paths:
        print(f"  已保存 → {out}")


# ══════════════════════════════════════════════════════════
# 图3：MPC 重构对比（原图 vs 重构图，两行）
# ══════════════════════════════════════════════════════════

def make_figure3(images_norm, recon_norm, cfg, max_err):
    """
    两行对比：
      第1行 原始蒸馏图像（反归一化）
      第2行 MPC 重构后的图像（反归一化）
    不显示坐标轴刻度/表格，不显示误差行。
    """
    tag = cfg['tag']
    n   = min(N_MPC_SHOW, len(images_norm))

    orig_01  = denormalize(images_norm[:n], cfg)
    recon_01 = denormalize(recon_norm[:n],  cfg)

    row_data   = [orig_01, recon_01]
    row_labels = ['Original(Distilled)', 'Reconstructed']

    # ┌─────────────────────────────────────────────────────┐
    # │  ★ [可手动调整] 图3 布局尺寸参数                     │
    # │  CELL    : 每张图片单元格的尺寸（英寸）               │
    # │  LABEL_W : 左侧行标签列宽度（英寸）                  │
    # │  TOP_PAD : 顶部标题区预留高度（英寸）                 │
    # │  BOT_PAD : 底部留白高度（英寸）                      │
    # └─────────────────────────────────────────────────────┘
    CELL    = 1.05    # ← [可手动调整] 图片单元格尺寸（英寸）
    LABEL_W = 1.20    # ← [可手动调整] 行标签列宽度（英寸）
    TOP_PAD = 0.08    # ← [可手动调整] 顶部留白（英寸）；标题已移除故缩小
    BOT_PAD = 0.15    # ← [可手动调整] 底部留白（英寸）

    fig_w = LABEL_W + n * CELL + 0.15
    fig_h = TOP_PAD + 2 * CELL + BOT_PAD

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor='white')

    # ★ 图3 标题已移除（不渲染 "MPC Reconstruction Fidelity…" 标题）
    # 如需恢复，取消下方注释并将 TOP_PAD 改回 0.30
    # fig.text(
    #     0.50,
    #     1.0 - 0.02 / fig_h,
    #     f"MPC Reconstruction Fidelity  [{tag}]",
    #     ha='center', va='top',
    #     fontsize=10,
    #     fontweight='bold',
    #     color='#1A1A2E',
    # )

    # 误差副标题（取消注释可显示）
    # fig.text(
    #     0.5, 1.0 - 0.32 / fig_h,
    #     f"Fixed-point scale $2^{{16}}$  |  "
    #     f"Max pixel error = {max_err:.2e}  |  "
    #     f"Theoretical bound = {1/FIXED_POINT_SCALE:.2e}",
    #     ha='center', va='top',
    #     fontsize=8, color='#555555',   # ← [可手动调整] 副标题字号和颜色
    # )

    # 布局比例（由尺寸参数自动推导）
    lf    = LABEL_W / fig_w
    tf    = TOP_PAD / fig_h
    row_h = (1.0 - tf - BOT_PAD / fig_h) / 2
    col_w = (1.0 - lf - 0.01) / n
    GAP   = 0.012   # ← [可手动调整] 图片间距比例

    for row in range(2):
        # ┌───────────────────────────────────────────────────┐
        # │  ★ [可手动调整] 图3 行标签样式                    │
        # │  fontsize    : 行标签字号                         │
        # │  color       : 行标签颜色                         │
        # │  fontweight  : 'bold' 加粗 / 'normal' 正常        │
        # │  lf-0.010    : 行标签到图片区的水平偏移            │
        # └───────────────────────────────────────────────────┘
        y_center = 1.0 - tf - (row + 0.5) * row_h
        fig.text(
            lf - 0.010,       # ← [可手动调整] 行标签到图片区水平偏移
            y_center,
            row_labels[row],
            ha='right', va='center',
            fontsize=8.5,     # ← [可手动调整] 行标签字号（pt）
            color='#1A1A2E',  # ← [可手动调整] 行标签颜色
            fontweight='bold' # ← [可手动调整] 字重：'bold' / 'normal'
        )

        for col in range(n):
            l = lf + col * col_w + col_w * GAP / 2
            b = 1.0 - tf - (row + 1) * row_h + row_h * GAP / 2
            w = col_w * (1 - GAP)
            h = row_h * (1 - GAP)

            ax = fig.add_axes([l, b, w, h])
            ax.imshow(to_hwc(row_data[row][col]), interpolation='nearest')
            ax.set_xticks([]); ax.set_yticks([])
            ax.tick_params(left=False, bottom=False,
                           labelleft=False, labelbottom=False)
            # ┌─────────────────────────────────────────────────┐
            # │  ★ [可手动调整] 图3 图片边框样式                │
            # └─────────────────────────────────────────────────┘
            for sp in ax.spines.values():
                sp.set_edgecolor('#BBBBBB')  # ← [可手动调整] 边框颜色
                sp.set_linewidth(0.3)        # ← [可手动调整] 边框粗细（pt，0=无边框）

    # ┌─────────────────────────────────────────────────────────┐
    # │  ★ [可手动调整] 图3 输出设置                            │
    # └─────────────────────────────────────────────────────────┘
    base_name = f'figure3_reconstructed_{tag.lower().replace("-","")}'
    saved_paths = save_figure_multi_format(fig, OUTPUT_DIR, base_name)
    plt.close(fig)
    for out in saved_paths:
        print(f"  已保存 → {out}")


# ══════════════════════════════════════════════════════════
# 主程序入口
# ══════════════════════════════════════════════════════════

def main():
    # 使用 ACTIVE_DATASET 决定图2、图3所用数据集
    if ACTIVE_DATASET not in DATASET_CONFIGS:
        raise ValueError(
            f"ACTIVE_DATASET='{ACTIVE_DATASET}' 不在配置中。\n"
            f"可用选项: {list(DATASET_CONFIGS.keys())}"
        )
    cfg  = DATASET_CONFIGS[ACTIVE_DATASET]
    tag  = cfg['tag']
    ftag = tag.lower().replace('-', '')

    print("=" * 60)
    print(f"  PLDK + NssMPC  ——  数据可视化管线")
    print(f"  图2/图3 数据集  : {tag}")
    print(f"  输出分辨率      : {DPI} dpi")
    print(f"  输出目录        : {OUTPUT_DIR}/")
    print("=" * 60)

    # ── [1] 加载当前数据集（供图2、图3使用）────────────────
    print(f"\n[1/6] 加载 {tag} 蒸馏数据（图2/图3用）...")
    images_norm, labels = load_distilled_data(cfg)

    # ── [2] 模拟 MPC 加密/重构流程 ─────────────────────────
    print("\n[2/6] 模拟 MPC 加密/重构流程...")
    show = images_norm[:N_MPC_SHOW].clone()
    ring           = float_to_ring(show)
    share0, share1 = additive_secret_share(ring)
    recon          = ring_to_float(share0, share1)
    max_err = (recon - show).abs().max().item()
    print(f"  最大重构误差 : {max_err:.2e}（理论上限 {1/FIXED_POINT_SCALE:.2e}）")
    assert max_err <= 1.0 / FIXED_POINT_SCALE + 1e-9, \
        "错误：重构误差超出定点精度上限，请检查 FIXED_POINT_SCALE！"
    print("  ✓ 重构精度验证通过")

    # ── [3] 加载两个数据集（供图1使用）─────────────────────
    print("\n[3/6] 加载 CIFAR-10 蒸馏数据（图1用）...")
    cifar_cfg  = DATASET_CONFIGS['cifar10']
    cifar_norm, cifar_labels = load_distilled_data(cifar_cfg)

    print("\n[4/6] 加载 STL-10 蒸馏数据（图1用）...")
    stl_cfg  = DATASET_CONFIGS['stl10']
    stl_norm, stl_labels = load_distilled_data(stl_cfg)
    stl_alias_for_cifar = {
        'automobile': 'car',
        'frog': 'monkey',
    }
    stl_order_for_combined = [
        stl_alias_for_cifar.get(name, name)
        for name in cifar_cfg['class_names']
    ]

    # ── [4] 方案A：两张独立图 ───────────────────────────────
    # CIFAR-10：显示左侧类名标签；STL-10：不显示类名标签
    print(f"\n[5/6] 生成图1（方案A：两张独立图）...")
    print("  生成 CIFAR-10 独立图（含类名标签）...")
    make_figure1(cifar_norm, cifar_labels, cifar_cfg, show_labels=True)
    print("  生成 STL-10 独立图（不含类名标签，顺序与 combined 图一致）...")
    make_figure1(
        stl_norm, stl_labels, stl_cfg,
        show_labels=False,
        class_order=stl_order_for_combined,
    )

    # ── [5] 方案B：CIFAR-10 + STL-10 并排合并图 ────────────
    print("\n  生成图1（方案B：CIFAR-10 与 STL-10 合并图）...")
    make_figure1_combined(
        cifar_norm, cifar_labels, cifar_cfg,
        stl_norm,   stl_labels,   stl_cfg,
    )

    # ── [6] 图2、图3（使用 ACTIVE_DATASET）─────────────────
    print(f"\n[6/6] 生成图2、图3（数据集：{tag}）...")
    make_figure2(images_norm, share0, share1, cfg)
    make_figure3(images_norm, recon,  cfg, max_err)

    # ── 输出摘要 ────────────────────────────────────────────
    print("\n" + "=" * 60)
    print(f"  全部图片已保存至 ./{OUTPUT_DIR}/")
    print(f"  ── 图1 方案A（独立图）──")
    print(f"    figure1_distilled_cifar10.png / .pdf   ← 含类名标签")
    print(f"    figure1_distilled_stl10.png   / .pdf   ← 不含类名标签")
    print(f"  ── 图1 方案B（合并图）──")
    print(f"    figure1_distilled_combined.png / .pdf  ← 中间留白分隔")
    print(f"  ── 图2 / 图3（数据集：{tag}）──")
    print(f"    figure2_secret_share_{ftag}.png / .pdf")
    print(f"    figure3_reconstructed_{ftag}.png / .pdf")
    print(f"\n  输出分辨率   : {DPI} dpi")
    print(f"  最大重构误差 : {max_err:.2e}")
    print("=" * 60)


if __name__ == '__main__':
    main()
