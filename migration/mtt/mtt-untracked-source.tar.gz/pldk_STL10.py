"""
PLDK Baseline for STL-10  —— MTT 蒸馏数据专用修复版
=======================================================
关键背景：
  MTT 蒸馏命令使用了 --res=32，因此蒸馏图像实际是 32×32，
  而非 STL-10 原始的 96×96。

修复了以下 5 个问题：
  [Fix A] DiffAugment: RandomCrop(96,pad=12) -> RandomCrop(32,pad=4)
          直接原因：对32×32图像 pad 后为56×56，再 crop 96 → 崩溃

  [Fix B] Student im_size: (96,96) -> (32,32)
          蒸馏数据是32×32，Student 必须与训练分辨率一致

  [Fix C] 测试集 Resize 到 32×32
          Student 只接受32×32输入，测试时需统一分辨率

  [Fix D] 教师推理前 Resize 到 96×96
          Teacher 由 train_teacher_STL10.py 在96×96上训练，
          直接喂32×32会导致 logits 质量严重下降；
          推理前先上采样到96×96，取完 logits 不影响 Student 训练

  [Fix E] 蒸馏数据加载改为 CPU，循环内再上 GPU
          直接 .to(device) 把全量32×32数据放 GPU 会浪费显存
          （虽然32×32比96×96小，但习惯上保持一致）
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
from torchvision.models import resnet18
import os
import time
import glob

# ==========================================
# 分辨率配置
# ==========================================
DISTILL_SIZE  = 32    # MTT 蒸馏图像分辨率（--res=32）
TEACHER_SIZE  = 96    # 教师模型训练分辨率（train_teacher_STL10.py）

# STL-10 归一化参数
STL10_MEAN = (0.4467, 0.4398, 0.4066)
STL10_STD  = (0.2603, 0.2566, 0.2713)


# ==========================================
# [Fix A] 数据增强：适配 32×32 蒸馏图像
# ==========================================
class DiffAugment(nn.Module):
    def __init__(self):
        super().__init__()
        self.aug = nn.Sequential(
            # 蒸馏图像是 32×32，padding = 32//8 = 4，与 CIFAR-10 baseline 一致
            transforms.RandomCrop(DISTILL_SIZE, padding=DISTILL_SIZE // 8),
            transforms.RandomHorizontalFlip(),
        )

    def forward(self, x):
        return self.aug(x)


def get_network_stl10(model_name, num_classes=10):
    """获取适配 STL-10（32×32蒸馏版）的网络"""
    if model_name == 'ConvNet':
        from utils import get_network
        # [Fix B] im_size 与蒸馏图像分辨率一致，不是原始96×96
        return get_network('ConvNet', channel=3, num_classes=num_classes,
                           im_size=(DISTILL_SIZE, DISTILL_SIZE))
    elif model_name == 'resnet18':
        net = resnet18(num_classes=num_classes)
        net.conv1   = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
        net.maxpool = nn.Identity()
        return net
    else:
        raise ValueError(f"Unknown model: {model_name}")


# ==========================================
# [Fix C] 测试集：resize 到蒸馏分辨率 32×32
# ==========================================
def get_stl10_test_loader(batch_size=256, data_path='./data'):
    """
    STL-10 测试集，图像 resize 到 DISTILL_SIZE（32×32）。
    Student 是在32×32上训练的，测试必须保持一致分辨率。
    """
    transform_test = transforms.Compose([
        transforms.Resize((DISTILL_SIZE, DISTILL_SIZE)),   # 96×96 → 32×32
        transforms.ToTensor(),
        transforms.Normalize(STL10_MEAN, STL10_STD),
    ])

    testset = torchvision.datasets.STL10(
        root=data_path, split='test', download=True, transform=transform_test)
    testloader = torch.utils.data.DataLoader(
        testset, batch_size=batch_size, shuffle=False, num_workers=2)

    return testloader


def pldk_train_stl10():
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Device: {device}")
    print("=" * 60)
    print("STL-10 PLDK Baseline Training（蒸馏分辨率: 32×32）")
    print("=" * 60)
    print(f"  蒸馏图像分辨率 : {DISTILL_SIZE}×{DISTILL_SIZE}（MTT --res=32）")
    print(f"  教师模型分辨率 : {TEACHER_SIZE}×{TEACHER_SIZE}（train_teacher_STL10.py）")
    print(f"  Student 分辨率 : {DISTILL_SIZE}×{DISTILL_SIZE}（与蒸馏数据一致）")

    # ==========================================
    # 1. 加载教师模型（在96×96上训练）
    # ==========================================
    print("\n加载教师模型（ResNet-18，96×96训练）...")
    teacher = get_network_stl10('resnet18', num_classes=10)

    teacher_path = 'teacher_resnet18_stl10.pth'
    if not os.path.exists(teacher_path):
        print(f"错误: 找不到 {teacher_path}")
        print("请先运行 train_teacher_STL10.py 训练教师模型")
        return

    teacher.load_state_dict(torch.load(teacher_path, map_location='cpu'))
    teacher = teacher.to(device)
    teacher.eval()

    # 用原始96×96测试集验证教师模型（教师本就是96×96训练的）
    print("\n验证教师模型（96×96测试集）...")
    transform_teacher_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(STL10_MEAN, STL10_STD),
    ])
    teacher_testset = torchvision.datasets.STL10(
        root='./data', split='test', download=True, transform=transform_teacher_test)
    teacher_test_loader = torch.utils.data.DataLoader(
        teacher_testset, batch_size=128, shuffle=False, num_workers=2)

    correct_t = total_t = 0
    with torch.no_grad():
        for inputs, targets in teacher_test_loader:
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = teacher(inputs)
            correct_t += outputs.max(1)[1].eq(targets).sum().item()
            total_t  += targets.size(0)
    teacher_acc = 100. * correct_t / total_t
    print(f"教师模型准确率（96×96）: {teacher_acc:.2f}%")
    if teacher_acc < 50:
        print("警告: 教师模型准确率过低，建议重新训练！")

    # ==========================================
    # 2. 加载蒸馏数据（32×32）[Fix E]
    # ==========================================
    print("\n加载蒸馏数据（MTT --res=32，图像尺寸应为 32×32）...")
    data_path = "images_best_stl10.pt"
    if not os.path.exists(data_path):
        files = glob.glob("**/images_best_stl10.pt", recursive=True)
        if files:
            data_path = files[0]
            print(f"自动找到: {data_path}")
        else:
            print("错误: 找不到 images_best_stl10.pt")
            return

    # [Fix E] map_location='cpu'，循环内再 .to(device)，避免一次性占用显存
    images_train = torch.load(data_path, map_location='cpu')
    labels_path  = data_path.replace('images_best_stl10.pt', 'labels_best_stl10.pt')
    labels_train = torch.load(labels_path, map_location='cpu')

    print(f"  蒸馏图像形状: {images_train.shape}")
    print(f"  蒸馏图像数量: {len(images_train)}")

    # 校验分辨率
    actual_h, actual_w = images_train.shape[-2], images_train.shape[-1]
    if actual_h != DISTILL_SIZE or actual_w != DISTILL_SIZE:
        print(f"  警告: 实际分辨率 {actual_h}×{actual_w} 与 DISTILL_SIZE={DISTILL_SIZE} 不一致")
        print(f"  自动更新 DISTILL_SIZE = {actual_h}")
        globals()['DISTILL_SIZE'] = actual_h

    # 归一化检查
    if images_train.max() <= 1.0 and images_train.min() >= 0.0:
        print("  应用 STL-10 归一化...")
        images_train = transforms.Normalize(STL10_MEAN, STL10_STD)(images_train)
        print(f"  归一化后值域: [{images_train.min():.3f}, {images_train.max():.3f}]")
    else:
        print("  数据已归一化，跳过。")

    # ==========================================
    # 3. 准备 Student 模型（ConvNet, 32×32）
    # ==========================================
    print("\n初始化 Student 模型（ConvNet，im_size=32×32）...")
    student = get_network_stl10('ConvNet', num_classes=10).to(device)
    optimizer = torch.optim.SGD(
        student.parameters(), lr=0.01, momentum=0.9, weight_decay=5e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=1000)

    # augmentor 在 GPU 上执行（已适配32×32）
    augmentor = DiffAugment().to(device)

    # PLDK 超参
    T_temp = 4.0
    alpha  = 0.5

    # 数据集：数据留 CPU，DataLoader 不做额外处理 [Fix E]
    class CPUTensorDataset(torch.utils.data.Dataset):
        def __init__(self, images, labels):
            self.images = images  # CPU
            self.labels = labels  # CPU
        def __getitem__(self, i):
            return self.images[i], self.labels[i]
        def __len__(self):
            return len(self.images)

    train_dataset = CPUTensorDataset(images_train, labels_train.long())
    train_loader  = torch.utils.data.DataLoader(
        train_dataset, batch_size=128, shuffle=True, num_workers=0)  # CPU tensor → num_workers=0

    # [Fix C] 测试集：resize 到 32×32 与 Student 分辨率一致
    test_loader = get_stl10_test_loader(batch_size=256, data_path='./data')
    print(f"  STL-10 测试集（resize 到 {DISTILL_SIZE}×{DISTILL_SIZE}）已加载")

    # ==========================================
    # 4. 训练
    # ==========================================
    print("\n开始训练...")
    print("=" * 70)
    print(f"{'Epoch':<8} {'Loss':<12} {'KD Loss':<12} {'CE Loss':<12} {'Test Acc':<10}")
    print("=" * 70)

    startTime = time.time()
    epochs    = 1000
    best_acc  = 0.0

    for epoch in range(epochs):
        student.train()
        total_loss = total_kd = total_ce = 0

        for imgs, labs in train_loader:
            # [Fix E] 循环内上 GPU
            imgs = imgs.to(device)
            labs = labs.to(device)

            # 数据增强（GPU，32×32）
            imgs = augmentor(imgs)

            # [Fix D] 教师推理：先 upsample 到96×96，取 logits 后 Student 不受影响
            with torch.no_grad():
                imgs_for_teacher = F.interpolate(
                    imgs, size=(TEACHER_SIZE, TEACHER_SIZE),
                    mode='bilinear', align_corners=False)   # 32→96
                teacher_logits = teacher(imgs_for_teacher)   # [B,10]

            # Student 直接在 32×32 上前向
            student_logits = student(imgs)

            # KD Loss
            kd_loss = F.kl_div(
                F.log_softmax(student_logits  / T_temp, dim=1),
                F.softmax(teacher_logits / T_temp, dim=1),
                reduction='batchmean'
            ) * (T_temp * T_temp)

            ce_loss = F.cross_entropy(student_logits, labs)
            loss    = alpha * kd_loss + (1 - alpha) * ce_loss

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += loss.item()
            total_kd   += kd_loss.item()
            total_ce   += ce_loss.item()

        scheduler.step()

        # 每100轮评估一次
        if (epoch + 1) % 100 == 0 or epoch == 0:
            student.eval()
            correct = total = 0
            with torch.no_grad():
                for inputs, targets in test_loader:
                    inputs, targets = inputs.to(device), targets.to(device)
                    outputs = student(inputs)
                    correct += outputs.max(1)[1].eq(targets).sum().item()
                    total   += targets.size(0)
            acc = 100. * correct / total

            n = len(train_loader)
            print(f"{epoch+1:<8} {total_loss/n:<12.4f} {total_kd/n:<12.4f} "
                  f"{total_ce/n:<12.4f} {acc:<10.2f}")

            if acc > best_acc:
                best_acc = acc
                torch.save(student.state_dict(), 'best_student_stl10.pth')
                # print(f"    新最佳模型！准确率: {acc:.2f}%")

    endTime = time.time()
    print("=" * 70)
    print(f"\n训练完成！总用时: {endTime - startTime:.1f}s")
    print(f"最佳准确率: {best_acc:.2f}%")
    print("模型已保存到: best_student_stl10.pth")


if __name__ == '__main__':
    pldk_train_stl10()