"""
教师模型精度测试脚本
支持数据集：CIFAR-10 和 STL-10

用法：
    python test_teacher_accuracy.py --dataset cifar10 --teacher_path teacher_resnet18_cifar10.pth
    python test_teacher_accuracy.py --dataset stl10 --teacher_path teacher_resnet18_stl10.pth
"""

import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
from torchvision.models import resnet18
import argparse
import os
from tqdm import tqdm

# ============================================================
# 配置参数
# ============================================================
DATASET_CONFIGS = {
    'cifar10': {
        'name': 'CIFAR-10',
        'mean': (0.4914, 0.4822, 0.4465),
        'std': (0.2023, 0.1994, 0.2010),
        'image_size': 32,
        'num_classes': 10,
        'test_split': 'test',
        'loader': lambda root, transform: torchvision.datasets.CIFAR10(
            root=root, train=False, download=True, transform=transform
        )
    },
    'stl10': {
        'name': 'STL-10',
        'mean': (0.4467, 0.4398, 0.4066),
        'std': (0.2603, 0.2566, 0.2713),
        'image_size': 96,
        'num_classes': 10,
        'test_split': 'test',
        'loader': lambda root, transform: torchvision.datasets.STL10(
            root=root, split='test', download=True, transform=transform
        )
    }
}

def get_teacher_model(num_classes=10, model_type='resnet18'):
    """
    创建教师模型（ResNet-18 适配 CIFAR/STL 尺寸）
    """
    if model_type == 'resnet18':
        model = resnet18(num_classes=num_classes)
        # 针对小尺寸图像的修改
        model.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
        model.maxpool = nn.Identity()
    else:
        raise ValueError(f"Unsupported model type: {model_type}")
    
    return model

def test_teacher_accuracy(args):
    """
    测试教师模型在指定数据集上的精度
    """
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")
    print("=" * 60)
    
    # 获取数据集配置
    if args.dataset not in DATASET_CONFIGS:
        raise ValueError(f"不支持的数据集: {args.dataset}，可选: {list(DATASET_CONFIGS.keys())}")
    
    cfg = DATASET_CONFIGS[args.dataset]
    print(f"数据集: {cfg['name']}")
    print(f"图像尺寸: {cfg['image_size']}×{cfg['image_size']}")
    print(f"类别数: {cfg['num_classes']}")
    print("-" * 60)
    
    # 数据预处理
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(cfg['mean'], cfg['std'])
    ])
    
    # 加载测试集
    print("加载测试集...")
    test_dataset = cfg['loader'](args.data_root, transform)
    test_loader = torch.utils.data.DataLoader(
        test_dataset, 
        batch_size=args.batch_size, 
        shuffle=False, 
        num_workers=args.num_workers
    )
    print(f"测试集大小: {len(test_dataset)} 张图片")
    print("-" * 60)
    
    # 创建教师模型
    print("创建教师模型...")
    teacher = get_teacher_model(num_classes=cfg['num_classes'], model_type=args.model_type)
    
    # 加载权重
    if not os.path.exists(args.teacher_path):
        raise FileNotFoundError(f"找不到教师模型文件: {args.teacher_path}")
    
    print(f"加载权重: {args.teacher_path}")
    state_dict = torch.load(args.teacher_path, map_location='cpu')
    
    # 兼容不同格式的权重文件
    if isinstance(state_dict, dict) and 'model' in state_dict:
        state_dict = state_dict['model']
    elif isinstance(state_dict, dict) and 'net' in state_dict:
        state_dict = state_dict['net']
    
    teacher.load_state_dict(state_dict)
    teacher = teacher.to(device)
    teacher.eval()
    print("模型加载成功！")
    print("-" * 60)
    
    # 测试模型精度
    print("测试中...")
    correct = 0
    total = 0
    
    # 逐类别统计
    class_correct = [0] * cfg['num_classes']
    class_total = [0] * cfg['num_classes']
    
    # CIFAR-10/STL-10 类别名称
    if args.dataset == 'cifar10':
        class_names = ['airplane', 'automobile', 'bird', 'cat', 'deer',
                       'dog', 'frog', 'horse', 'ship', 'truck']
    else:  # stl10
        class_names = ['airplane', 'bird', 'car', 'cat', 'deer',
                       'dog', 'horse', 'monkey', 'ship', 'truck']
    
    with torch.no_grad():
        for images, labels in tqdm(test_loader, desc="评估进度"):
            images, labels = images.to(device), labels.to(device)
            outputs = teacher(images)
            _, predicted = torch.max(outputs, 1)
            
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            
            # 逐类别统计
            for i in range(len(labels)):
                label = labels[i].item()
                class_correct[label] += (predicted[i] == labels[i]).item()
                class_total[label] += 1
    
    # 计算总体精度
    accuracy = 100.0 * correct / total
    print("=" * 60)
    print(f"测试完成！")
    print(f"总体准确率: {accuracy:.2f}% ({correct}/{total})")
    print("=" * 60)
    
    # 打印各类别精度
    print("\n各类别准确率:")
    print("-" * 40)
    for i in range(cfg['num_classes']):
        if class_total[i] > 0:
            class_acc = 100.0 * class_correct[i] / class_total[i]
            print(f"类别 {i:2d} ({class_names[i]:12s}): {class_acc:6.2f}% ({class_correct[i]:3d}/{class_total[i]:3d})")
    
    print("=" * 60)
    
    # 保存结果到文件
    if args.save_result:
        result_file = f"teacher_accuracy_{args.dataset}.txt"
        with open(result_file, 'w') as f:
            f.write(f"教师模型精度测试结果\n")
            f.write(f"数据集: {cfg['name']}\n")
            f.write(f"模型文件: {args.teacher_path}\n")
            f.write(f"总体准确率: {accuracy:.2f}%\n\n")
            f.write("各类别准确率:\n")
            for i in range(cfg['num_classes']):
                if class_total[i] > 0:
                    class_acc = 100.0 * class_correct[i] / class_total[i]
                    f.write(f"类别 {i}: {class_acc:.2f}%\n")
        print(f"\n结果已保存到: {result_file}")
    
    return accuracy

def main():
    parser = argparse.ArgumentParser(description='测试教师模型精度')
    parser.add_argument('--dataset', type=str, default='cifar10',
                        choices=['cifar10', 'stl10'],
                        help='数据集 (cifar10 或 stl10)')
    parser.add_argument('--teacher_path', type=str, 
                        default='teacher_resnet18_cifar10.pth',
                        help='教师模型权重文件路径')
    parser.add_argument('--model_type', type=str, default='resnet18',
                        help='模型类型 (默认: resnet18)')
    parser.add_argument('--data_root', type=str, default='./data',
                        help='数据集根目录')
    parser.add_argument('--batch_size', type=int, default=128,
                        help='测试批次大小')
    parser.add_argument('--num_workers', type=int, default=4,
                        help='数据加载线程数')
    parser.add_argument('--save_result', action='store_true',
                        help='保存测试结果到文件')
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("教师模型精度测试")
    print("=" * 60)
    print(f"数据集: {args.dataset}")
    print(f"模型文件: {args.teacher_path}")
    print(f"批次大小: {args.batch_size}")
    print("=" * 60)
    
    test_teacher_accuracy(args)

if __name__ == '__main__':
    main()