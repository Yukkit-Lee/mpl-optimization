"""
学术风格 matplotlib 绘图脚本（v4）
数据来源：
  - 图1 : Table 2（CIFAR-10 / STL-10 隐私-效用权衡散点图）
  - 图2 : Table 3（异构蒸馏基线对比）
  - 图3 : Table 4（跨范式 DP / 正则化基线对比）

输出文件（PDF + PNG，300 dpi）：
  fig1_tradeoff.pdf / .png
  heterogeneous_cifar10.pdf  / .png
  heterogeneous_stl10.pdf    / .png
  privacy_cifar10.pdf        / .png
  privacy_stl10.pdf          / .png

配色参考：LDPKiT 论文 Fig.4 / Fig.7 的蓝-橙-绿-红标准学术配色
"""

import os
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.transforms as mtransforms
from matplotlib.lines import Line2D

# ══════════════════════════════════════════════════════════════════════════════
# ❶  全局字体 / 字号 / 字重设置
#    所有文字大小在此统一控制；想整体缩小就把各项数字同比减小
# ══════════════════════════════════════════════════════════════════════════════
matplotlib.rcParams.update({
    "font.family":        "serif",
    "font.serif":         ["Times New Roman", "DejaVu Serif"],
    "font.size":          11,          # ← [可调] 全局基础字号（影响所有未单独设置的文字）
    "axes.titlesize":     12,          # ← [可调] 子图标题字号（"(a) Test Acc (%)" 等）
    "axes.titleweight":   "bold",      # ← [可调] 子图标题字重："bold" / "normal"
    "axes.labelsize":     11,          # ← [可调] 坐标轴标签字号（"Test Acc (%)" 等）
    "axes.labelweight":   "bold",      # ← [可调] 坐标轴标签字重："bold" / "normal"
    "xtick.labelsize":    10,          # ← [可调] 横轴刻度文字字号
    "ytick.labelsize":    10,          # ← [可调] 纵轴刻度文字字号
    "legend.fontsize":    9.5,         # ← [可调] 图例文字字号
    "legend.title_fontsize": 10,       # ← [可调] 图例标题字号
    "legend.framealpha":  0.92,        # ← 图例背景透明度
    "legend.edgecolor":   "#bbbbbb",   # ← 图例边框颜色
    "axes.spines.top":    False,
    "axes.spines.right":  False,
    "figure.dpi":         150,
    "savefig.dpi":        300,
    "savefig.bbox":       "tight",
})

# ══════════════════════════════════════════════════════════════════════════════
# ❷  横轴文字对齐微调（图2 / 图3 独立控制）
# ══════════════════════════════════════════════════════════════════════════════
XTICK_TUNE_FIG2 = {"rotation": 20, "ha": "center", "pad": 3.0, "dx": 0.0, "dy": 0.0}
XTICK_TUNE_FIG3 = {"rotation": 28, "ha": "center", "pad": 3.0, "dx": 0.0, "dy": 0.0}
FIG2_XTICK_FONTWEIGHT = "bold"   # ← [可调] 图2 横轴方法名字重："bold" / "normal"
FIG3_XTICK_FONTWEIGHT = "bold"   # ← [可调] 图3 横轴方法名字重："bold" / "normal"
FIG2_YTICK_FONTWEIGHT = "bold"   # ← [可调] 图2 纵轴刻度字重："bold" / "normal"
FIG3_YTICK_FONTWEIGHT = "bold"   # ← [可调] 图3 纵轴刻度字重："bold" / "normal"

FIG3_SPECIAL_TICK_FONTS = {
    "DP-SGD\n(ε=198.5)": 8,   # ← [可调] DP-SGD 标签字号，防止堆叠
    "DP-SGD\n(ε=50.2)":  8,
}

# ══════════════════════════════════════════════════════════════════════════════
# ❸  全局配色总表
#    参考 LDPKiT 论文 Fig.4 / Fig.7 的配色风格：
#      蓝  (#4472C4) → 橙  (#ED7D31) → 绿  (#70AD47) → 深红 (#C00000)
#    想整体换色系只需改这里
# ══════════════════════════════════════════════════════════════════════════════
# 散点图 / 通用颜色
C_STANDARD  = "#4472C4"   # ← [可调] 传统防御方法颜色（蓝，paper-style）
C_DISTILL   = "#ED7D31"   # ← [可调] 蒸馏基线方法颜色（橙，paper-style）
C_OURS_PLDK = "#70AD47"   # ← [可调] PLDK+MPC 颜色（绿，paper-style）
C_OURS      = "#C00000"   # ← [可调] Ours 颜色（深红，最突出，paper-style）
C_RANDOM    = "#393937"   # ← [可调] random-guess 参考线颜色（棕金色，避免与 QL-PGD 的紫色重复）

# ── 图2 柱状图配色 ─────────────────────────────────────────────────────────────
# Test Acc 子图：4 个方法各用一种颜色，末位是 Ours
# 参考论文 Fig.4 蓝/橙/绿/深红的分组配色
bar_cols_base = [
    "#4472C4",   # ← [可调] FedMD 柱颜色（蓝）
    "#ED7D31",   # ← [可调] FedKD 柱颜色（橙）
    "#70AD47",   # ← [可调] Sel.-FD 柱颜色（绿）
    C_OURS,      # ← [可调] Ours 柱颜色（深红，复用全局 C_OURS）
]

# Priv Acc 子图：Ab（实色）和 Aw（同色系浅版）
# 保持各方法颜色身份一致：蓝=FedMD, 橙=FedKD, 绿=Sel.-FD, 红=Ours
bar_cols_Ab = [
    "#4472C4",   # ← [可调] FedMD Ab 柱（蓝，实色）
    "#ED7D31",   # ← [可调] FedKD Ab 柱（橙，实色）
    "#70AD47",   # ← [可调] Sel.-FD Ab 柱（绿，实色）
    C_OURS,      # ← [可调] Ours Ab 柱（深红）
]
bar_cols_Aw = [
    "#9DC3E6",   # ← [可调] FedMD Aw 柱（浅蓝，Ab 的浅色版）
    "#F4B183",   # ← [可调] FedKD Aw 柱（浅橙）
    "#A9D18E",   # ← [可调] Sel.-FD Aw 柱（浅绿）
    "#FF8080",   # ← [可调] Ours Aw 柱（浅红）
]

# ── 图3 柱状图配色 ─────────────────────────────────────────────────────────────
# 改为与图2一致的“离散分类配色”风格，而不是蓝色渐变。
# 前3个沿用图2的蓝 / 橙 / 绿；额外补两个互相区分度高的颜色；末位 Ours 仍为深红。
RAMP = [
    "#4472C4",   # ← [可调] PATE（蓝，延续图2风格）
    "#ED7D31",   # ← [可调] DP-SGD (ε=198.5)（橙）
    "#70AD47",   # ← [可调] DP-SGD (ε=50.2)（绿）
    "#5B9BD5",   # ← [可调] HierarchicalDP（补充色1：亮蓝）
    "#8064A2",   # ← [可调] QL-PGD（补充色2：紫）
    C_OURS,      # ← [可调] Ours（深红，复用全局 C_OURS）
]

# ── 图3：Ours 数值标注位置微调 ───────────────────────────────────────────────
# 想手动调位置，优先改这几个参数：
#   DX：左右移动，正数向右，负数向左
#   DY：上下移动，正数向上，负数向下
FIG3_OURS_TEST_LABEL_DX = 0.00   # ← [可调] 图3 Test Acc 子图中 Ours 数值横向偏移
FIG3_OURS_TEST_LABEL_DY = 0.90   # ← [可调] 图3 Test Acc 子图中 Ours 数值纵向偏移
FIG3_OURS_PRIV_LABEL_DX = 0.00   # ← [可调] 图3 Priv Acc 子图中 Ours 数值横向偏移
FIG3_OURS_PRIV_LABEL_DY = 0.55   # ← [可调] 图3 Priv Acc 子图中 Ours 数值纵向偏移

# ── 图3：random-guess 文字说明模式 ────────────────────────────────────────────
# 可选：
#   "legend_only" : 不在图中写文字，只在图例保留说明（默认，最干净）
#   "arrow_note"  : 文字放到图中空白处，并用箭头指向 50% 参考线
FIG3_RANDOM_GUESS_MODE = "legend_only"
FIG3_RANDOM_GUESS_NOTE = {
    "x_text": 0.03,      # ← [可调] 文字横向位置（轴坐标）
    "y_text": 52.2,      # ← [可调] 文字纵向位置（数据坐标）
    "x_line": 0.10,      # ← [可调] 箭头指向点横向位置（轴坐标）
    "y_line": 50.0,      # ← [可调] 箭头指向点纵向位置（数据坐标）
}

# ── 图2：random-guess 文字说明位置（统一改成方案1：空白处 + 箭头）──────────────
FIG2_RANDOM_GUESS_MODE = "legend_only"
FIG2_RANDOM_GUESS_NOTE = {
    "x_text": 0.03,      # ← [可调] 图2 文字横向位置（轴坐标）
    "y_text": 52.8,      # ← [可调] 图2 文字纵向位置（数据坐标）
    "x_line": 0.10,      # ← [可调] 图2 箭头指向点横向位置（轴坐标）
    "y_line": 50.0,      # ← [可调] 图2 箭头指向点纵向位置（数据坐标）
}

# ══════════════════════════════════════════════════════════════════════════════
# ❹  输出路径
# ══════════════════════════════════════════════════════════════════════════════
OUT = "./papers_figure_latex"
os.makedirs(OUT, exist_ok=True)

# ══════════════════════════════════════════════════════════════════════════════
# ❺  图1 数据（来自 Table 2）
# ══════════════════════════════════════════════════════════════════════════════
data_t2_cifar = [
    ("No Defense",       67.46, 76.80, 0),
    ("Regu (WD+LS)",     53.20, 53.00, 0),
    ("DMP",              65.00, 50.60, 1),
    ("PLDK",             69.30, 50.21, 1),
    ("PLDK + MPC",       65.61, 50.22, 2),
    ("MPC + KA\n(Ours)", 64.36, 49.62, 3),
]
data_t2_stl = [
    ("No Defense",       59.58, 73.18, 0),
    ("Regu (WD+LS)",     55.73, 68.02, 0),
    ("DMP",              45.86, 51.08, 1),
    ("PLDK",             40.90, 49.38, 1),
    ("PLDK + MPC",       41.88, 49.25, 2),
    ("MPC + KA\n(Ours)", 49.51, 49.85, 3),
]

# 散点样式：(marker形状, 颜色, 点大小, zorder, 边框宽度)
cat_style = {
    0: ("o",  C_STANDARD,  65,  2, 0.7),    # ← [可调] 传统防御：圆点
    1: ("s",  C_DISTILL,   65,  2, 0.7),    # ← [可调] 蒸馏基线：方点
    2: ("D",  C_OURS_PLDK, 75,  3, 1.0),    # ← [可调] PLDK+MPC：菱形
    3: ("*",  C_OURS,      160, 4, 1.3),    # ← [可调] Ours：星形（最大最突出）
}

ANNOTATE = {"No Defense", "DMP", "PLDK", "MPC + KA\n(Ours)"}

# ══════════════════════════════════════════════════════════════════════════════
# ❻  图2 数据（来自 Table 3）
# ══════════════════════════════════════════════════════════════════════════════
methods_t3 = ["FedMD", "FedKD", "Selective-FD", "Ours\n(dist.500)"]
t3_c_test = [79.37, 78.66, 68.98, 64.36]
t3_c_Ab   = [69.25, 73.88, 51.18, 49.62]
t3_c_Aw   = [72.91, 79.17, 54.44, 49.94]
t3_s_test = [43.52, 43.09, 34.89, 49.51]
t3_s_Ab   = [49.85, 49.85, 49.95, 49.85]
t3_s_Aw   = [50.55, 50.42, 51.08, 49.92]

BAR_W = 0.20   # ← [可调] 图2 隐私子图每根柱子宽度（数据坐标，增大=更粗）

# ══════════════════════════════════════════════════════════════════════════════
# ❼  图3 数据（来自 Table 4）
# ══════════════════════════════════════════════════════════════════════════════
methods_t4 = [
    "PATE", "DP-SGD\n(ε=198.5)", "DP-SGD\n(ε=50.2)",
    "Hierarchical\nDP", "QL-PGD", "Ours",
]
labels_short4 = [
    "PATE", "DP-SGD\n(ε=198.5)", "DP-SGD\n(ε=50.2)",
    "Hier.DP",   # ← [可调] 可改回 "HierarchicalDP"
    "QL-PGD", "Ours",
]
t4_c_test = [40.59, 56.59, 53.85, 48.56, 60.99, 64.36]
t4_c_Ab   = [50.01, 50.49, 50.14, 50.99, 50.34, 49.62]
t4_s_test = [26.07, 42.11, 40.61, 34.75, 44.01, 49.51]
t4_s_Ab   = [50.62, 49.42, 49.72, 49.58, 54.44, 49.85]


# ══════════════════════════════════════════════════════════════════════════════
# 辅助函数
# ══════════════════════════════════════════════════════════════════════════════
def apply_xtick_label_tuning(ax, tick_positions, labels, tune, fontsize=None,
                             fontweight=None):
    ax.set_xticks(tick_positions)
    texts = ax.set_xticklabels(labels, rotation=tune["rotation"],
                               ha=tune["ha"], fontsize=fontsize)
    ax.tick_params(axis="x", pad=tune["pad"])
    for text in texts:
        if fontweight is not None:
            text.set_fontweight(fontweight)
        offset = mtransforms.ScaledTranslation(
            tune["dx"] / 72.0, tune["dy"] / 72.0,
            ax.figure.dpi_scale_trans)
        text.set_transform(text.get_transform() + offset)
    return texts


def apply_special_tick_fontsizes(texts, font_map):
    for text in texts:
        if text.get_text() in font_map:
            text.set_fontsize(font_map[text.get_text()])


def set_ytick_fontweight(ax, fontweight):
    """
    统一设置纵轴刻度文字字重。

    适用于你后续想统一调粗图2 / 图3的 y 轴数字时使用。
    """
    for text in ax.get_yticklabels():
        text.set_fontweight(fontweight)


def draw_random_guess_inline(ax, y=50, x_axes=0.02, y_offset=0.6,
                              label="Random guess"):
    """
    在坐标轴内部（左侧）绘制 random-guess 文字标注。
    使用 yaxis_transform：x 为轴坐标 [0,1]（0=左端, 1=右端），y 为数据坐标。
    这样文字始终在图内，不占图表右侧空间。

    ★ [可调] 参数说明：
      y        : random-guess 参考线的 y 数据坐标（默认50）
      x_axes   : 文字的横向位置（轴坐标，0=最左，1=最右）← 改这里调左右位置
      y_offset : 文字在参考线上方的数据坐标偏移量     ← 改这里调上下距离
      label    : 显示的文字内容
    """
    ax.text(
        x_axes,                          # ← [可调] 横向位置（0=最左端，0.5=中央）
        y + y_offset,                    # ← [可调] 纵向位置（参考线上方偏移量）
        label,
        transform=ax.get_yaxis_transform(),   # x轴坐标，y数据坐标
        ha="left", va="bottom",
        color=C_RANDOM,                  # ← [可调] 文字颜色（同 C_RANDOM）
        fontsize=9,                      # ← [可调] 文字字号
        fontweight="bold",               # ← [可调] 字重："bold" / "normal"
        alpha=0.9,
    )


def draw_random_guess_arrow_note(ax, note_cfg, label="Random guess (50%)"):
    """
    方案1：把 random-guess 文字放到图中空白处，并用箭头指向 50% 参考线。

    说明：
      - x_text / x_line 使用轴坐标（0=左端，1=右端）
      - y_text / y_line 使用数据坐标
      - 若文字仍与柱子重叠，优先调 note_cfg 里的 x_text / y_text
    """
    ax.annotate(
        label,
        xy=(note_cfg["x_line"], note_cfg["y_line"]),
        xycoords=ax.get_yaxis_transform(),
        xytext=(note_cfg["x_text"], note_cfg["y_text"]),
        textcoords=ax.get_yaxis_transform(),
        ha="left",
        va="bottom",
        color=C_RANDOM,
        fontsize=8.5,
        fontweight="bold",
        arrowprops=dict(arrowstyle="->", color=C_RANDOM, lw=0.9),
    )


# ══════════════════════════════════════════════════════════════════════════════
# ▌图1：隐私-效用权衡散点图
# ══════════════════════════════════════════════════════════════════════════════
def scatter_panel(ax, data, title):
    ax.set_facecolor("white")
    ax.yaxis.grid(True, color="#e0e0e0", linewidth=0.6, zorder=0)
    ax.set_axisbelow(True)

    # random-guess 竖虚线
    ax.axvline(x=50,
               color=C_RANDOM,       # ← [可调] 参考线颜色
               linestyle="--",        # ← [可调] 线型
               linewidth=1.2,         # ← [可调] 参考线粗细
               alpha=0.85, zorder=1)

    # ★ [可调] 散点图中 random-guess 文字位置
    # 此处 x_data=50.6 是数据坐标，y_data 从 ylim 底部算起
    # 如需左移/右移文字，调整 50.6 这个数值
    ax.text(
        50.6,                                           # ← [可调] 文字横向数据坐标（靠参考线右侧）
        ax.get_ylim()[0] + 0.5 if ax.get_ylim()[0] > 0 else 37,
        "random\nguess",
        color=C_RANDOM,    # ← [可调] 文字颜色
        fontsize=8.5,      # ← [可调] 文字字号
        fontweight="bold", # ← [可调] 字重
        va="bottom", alpha=0.9,
    )

    for label, test, priv, cat in data:
        mk, col, sz, zo, ew = cat_style[cat]
        ax.scatter(priv, test, marker=mk, color=col, s=sz,
                   edgecolors="white", linewidths=ew, zorder=zo)
        if label in ANNOTATE:
            dx, dy = 0.6, 0.8
            if label == "No Defense":
                dx, dy = 0.6, 1.5
            elif label == "DMP":
                dx, dy = 0.6, -2.5
            elif label == "PLDK":
                dx, dy = 0.6, 1.2
            elif "Ours" in label:
                dx, dy = -5.5, 1.8
            clean = label.replace("\n", " ")
            ax.annotate(clean, (priv, test),
                        xytext=(priv + dx, test + dy),
                        fontsize=8.5,            # ← [可调] 标注文字字号
                        fontweight="bold",       # ← [可调] 字重
                        color="#111111",
                        arrowprops=dict(arrowstyle="-", color="#aaaaaa", lw=0.7),
                        ha="left" if dx > 0 else "right")

    ax.set_xlabel("Priv Acc (Ab) (%)", labelpad=4)
    ax.set_ylabel("Test Acc (%)", labelpad=4)
    ax.set_title(title, pad=6)


fig1, axes = plt.subplots(1, 2,
                           figsize=(7.2, 3.4),   # ← [可调] 图1 画布尺寸（宽×高，英寸）
                           constrained_layout=True)

for ax, data, sub in zip(axes,
                         [data_t2_cifar, data_t2_stl],
                         ["(a) CIFAR-10", "(b) STL-10"]):
    tests = [d[1] for d in data]
    ax.set_ylim(min(tests) - 5, max(tests) + 8)
    ax.set_xlim(46, 82)
    scatter_panel(ax, data, sub)

legend_handles = [
    Line2D([0], [0], marker="o", color="w", markerfacecolor=C_STANDARD,
           markersize=7, label="Standard defenses"),
    Line2D([0], [0], marker="s", color="w", markerfacecolor=C_DISTILL,
           markersize=7, label="Distillation baselines"),
    Line2D([0], [0], marker="D", color="w", markerfacecolor=C_OURS_PLDK,
           markersize=7, label="PLDK + MPC"),
    Line2D([0], [0], marker="*", color="w", markerfacecolor=C_OURS,
           markersize=10, label="MPC + KA (Ours)"),
    Line2D([0], [0], linestyle="--", color=C_RANDOM,
           linewidth=1.2, label="Random-guess boundary"),
]
# ★ [可调] 图1 图例位置
# bbox_to_anchor=(0.5, -0.08) 表示图下方；改为 (0.5, 1.0) 则在图上方
fig1.legend(handles=legend_handles,
            loc="lower center",
            bbox_to_anchor=(0.5, -0.08),   # ← [可调] 图例纵向位置（负值=图下方）
            ncol=3,
            frameon=True, handlelength=1.5, columnspacing=1.0,
            borderpad=0.6)

for fmt in ("pdf", "png"):
    fig1.savefig(os.path.join(OUT, f"fig1_tradeoff.{fmt}"),
                 format=fmt, bbox_inches="tight", dpi=300)
print("Figure 1 saved.")
plt.close(fig1)


# ══════════════════════════════════════════════════════════════════════════════
# ▌图2 公用函数
# ══════════════════════════════════════════════════════════════════════════════
def grouped_bars_privacy(ax, x, ab_vals, aw_vals, cols_ab, cols_aw,
                         method_labels, title):
    """隐私子图：每个方法画 Ab / Aw 两根并排柱。"""
    ax.set_facecolor("white")
    ax.yaxis.grid(True, color="#e0e0e0", linewidth=0.6, zorder=0)
    ax.set_axisbelow(True)

    ax.axhline(50,
               color=C_RANDOM,     # ← [可调] random-guess 参考线颜色
               linestyle="--",      # ← [可调] 线型
               linewidth=1.2,       # ← [可调] 线粗
               alpha=0.85, zorder=5)

    offsets = [-0.5 * BAR_W, 0.5 * BAR_W]
    for i, (ab, aw, ca, cw) in enumerate(zip(ab_vals, aw_vals, cols_ab, cols_aw)):
        ax.bar(x[i] + offsets[0], ab,
               width=BAR_W, color=ca, edgecolor="white", linewidth=0.5, zorder=3)
        ax.bar(x[i] + offsets[1], aw,
               width=BAR_W, color=cw, edgecolor="white", linewidth=0.5, zorder=3)

        if i == len(ab_vals) - 1:  # 只给 Ours 标数值
            ax.text(x[i] + offsets[0] - 0.12, ab + 0.9,
                    f"{ab:.2f}", ha="center", va="bottom",
                    fontsize=8,              # ← [可调] Ours 数值字号
                    color=cols_ab[i], fontweight="bold")
            ax.text(x[i] + offsets[1] + 0.11, aw + 0.9,
                    f"{aw:.2f}", ha="center", va="bottom",
                    fontsize=8,
                    color=cols_aw[i], fontweight="bold")

    # ★ [可调] 图2 横轴方法名（FedMD / FedKD / Sel.-FD / Ours）加粗位置
    # 想改字重，优先修改顶部 FIG2_XTICK_FONTWEIGHT
    apply_xtick_label_tuning(
        ax, x, method_labels, XTICK_TUNE_FIG2,
        fontweight=FIG2_XTICK_FONTWEIGHT,
    )
    # ★ [可调] 图2 纵轴标题加粗位置
    # 当前字重由顶部 matplotlib.rcParams["axes.labelweight"] 统一控制。
    ax.set_ylabel("Priv Acc (%)", labelpad=3)
    ax.set_title(title, pad=6)
    all_vals = list(ab_vals) + list(aw_vals)
    ax.set_ylim(44, max(all_vals) + 10)

    # ★ [可调] 图2 纵轴刻度数字加粗位置
    # 想改字重，优先修改顶部 FIG2_YTICK_FONTWEIGHT
    set_ytick_fontweight(ax, FIG2_YTICK_FONTWEIGHT)
    # 图2 的 random guess 现已改为方案2：只在图例中显示，不在图内放文字说明。


def bar_test(ax, x, vals, cols, method_labels, title, ylabel="Test Acc (%)"):
    """Test Acc 柱状图。"""
    ax.set_facecolor("white")
    ax.yaxis.grid(True, color="#e0e0e0", linewidth=0.6, zorder=0)
    ax.set_axisbelow(True)
    for i, (v, c) in enumerate(zip(vals, cols)):
        ax.bar(x[i], v,
               width=0.52,          # ← [可调] 图2 Test Acc 柱宽
               color=c,
               edgecolor="white",
               linewidth=0.5, zorder=3)
        if i == len(vals) - 1:
            ax.text(x[i], v + 0.7, f"{v:.1f}",
                    ha="center", va="bottom",
                    fontsize=8.5,        # ← [可调] Ours 数值标注字号
                    color=C_OURS, fontweight="bold")
    # ★ [可调] 图2 横轴方法名（FedMD / FedKD / Sel.-FD / Ours）加粗位置
    # 想改字重，优先修改顶部 FIG2_XTICK_FONTWEIGHT
    apply_xtick_label_tuning(
        ax, x, method_labels, XTICK_TUNE_FIG2,
        fontweight=FIG2_XTICK_FONTWEIGHT,
    )
    # ★ [可调] 图2 纵轴标题加粗位置
    # 当前字重由顶部 matplotlib.rcParams["axes.labelweight"] 统一控制。
    ax.set_ylabel(ylabel, labelpad=3)
    ax.set_title(title, pad=6)
    ax.set_ylim(0, max(vals) + 14)
    # ★ [可调] 图2 纵轴刻度数字加粗位置
    # 想改字重，优先修改顶部 FIG2_YTICK_FONTWEIGHT
    set_ytick_fontweight(ax, FIG2_YTICK_FONTWEIGHT)


# ══════════════════════════════════════════════════════════════════════════════
# ▌图2：异构蒸馏基线对比  →  输出为 heterogeneous_*.pdf/png
# ══════════════════════════════════════════════════════════════════════════════
x3_pos      = np.arange(len(methods_t3))
labels_short = ["FedMD", "FedKD", "Sel.-FD", "Ours"]   # ← [可调] 横轴标签缩写

# ── 图2 图例 ──────────────────────────────────────────────────────────────────
leg2_handles = [
    mpatches.Patch(color=bar_cols_Ab[0], label="Priv Acc (Ab) — FedMD"),
    mpatches.Patch(color=bar_cols_Aw[0], label="Priv Acc (Aw) — FedMD"),
    mpatches.Patch(color=bar_cols_Ab[1], label="Priv Acc (Ab) — FedKD"),
    mpatches.Patch(color=bar_cols_Aw[1], label="Priv Acc (Aw) — FedKD"),
    mpatches.Patch(color=bar_cols_Ab[2], label="Priv Acc (Ab) — Sel.-FD"),
    mpatches.Patch(color=bar_cols_Aw[2], label="Priv Acc (Aw) — Sel.-FD"),
    mpatches.Patch(color=bar_cols_Ab[3], label="Priv Acc (Ab) — Ours"),
    mpatches.Patch(color=bar_cols_Aw[3], label="Priv Acc (Aw) — Ours"),
    Line2D([0], [0], linestyle="--", color=C_RANDOM,
           linewidth=1.2, label="Random guess (50%)"),
]
# 简洁版图例（仅区分 Ab/Aw 和 Ours）
leg2_handles_simple = [
    mpatches.Patch(color="#888888", label="Priv Acc (Ab)  (solid)"),
    mpatches.Patch(color="#bbbbbb", label="Priv Acc (Aw)  (light)"),
    mpatches.Patch(color=bar_cols_base[0], label="FedMD"),
    mpatches.Patch(color=bar_cols_base[1], label="FedKD"),
    mpatches.Patch(color=bar_cols_base[2], label="Sel.-FD"),
    mpatches.Patch(color=C_OURS,           label="Ours"),
    Line2D([0], [0], linestyle="--", color=C_RANDOM,
           linewidth=1.2, label="Random guess"),
]

# ── Figure 2a：CIFAR-10 ── 输出名：heterogeneous_cifar10 ─────────────────────
fig2a, ax2a = plt.subplots(1, 2,
                            figsize=(7.4, 3.4),   # ← [可调] 图2 画布尺寸
                            constrained_layout=True)

bar_test(ax2a[0], x3_pos, t3_c_test, bar_cols_base,
         labels_short, "(a) Test Acc (%)")

grouped_bars_privacy(ax2a[1], x3_pos,
                     t3_c_Ab, t3_c_Aw,
                     bar_cols_Ab, bar_cols_Aw,
                     labels_short, "(b) Priv Acc (%)")

# ★ [可调] 图2a 图例位置
# loc="upper center" + bbox_to_anchor=(0.5, 1.02) → 图上方紧贴（比 lower center 更近）
# 也可改为 loc="lower center", bbox_to_anchor=(0.5, -0.12) 放在图下方
fig2a.legend(handles=leg2_handles_simple,
             loc="lower center",
             bbox_to_anchor=(0.5, -0.20),    # ← [可调] 图例位置：(水平, 垂直)
             ncol=4,                          # ← [可调] 图例列数
             frameon=True, handlelength=1.3,
             handletextpad=0.5, columnspacing=0.8,
             borderpad=0.5)

for fmt in ("pdf", "png"):
    fig2a.savefig(os.path.join(OUT, f"heterogeneous_cifar10.{fmt}"),
                  format=fmt, bbox_inches="tight", dpi=300)
print("Figure 2a (heterogeneous_cifar10) saved.")
plt.close(fig2a)

# ── Figure 2b：STL-10 ── 输出名：heterogeneous_stl10 ─────────────────────────
fig2b, ax2b = plt.subplots(1, 2,
                            figsize=(7.4, 3.4),   # ← [可调] 画布尺寸
                            constrained_layout=True)

bar_test(ax2b[0], x3_pos, t3_s_test, bar_cols_base,
         labels_short, "(a) Test Acc (%)")

grouped_bars_privacy(ax2b[1], x3_pos,
                     t3_s_Ab, t3_s_Aw,
                     bar_cols_Ab, bar_cols_Aw,
                     labels_short, "(b) Priv Acc (%)")

# ★ [可调] 图2b 图例位置（同 2a）
fig2b.legend(handles=leg2_handles_simple,
             loc="lower center",
             bbox_to_anchor=(0.5, -0.20),    # ← [可调] 图例位置
             ncol=4, frameon=True, handlelength=1.3,
             handletextpad=0.5, columnspacing=0.8,
             borderpad=0.5)

for fmt in ("pdf", "png"):
    fig2b.savefig(os.path.join(OUT, f"heterogeneous_stl10.{fmt}"),
                  format=fmt, bbox_inches="tight", dpi=300)
print("Figure 2b (heterogeneous_stl10) saved.")
plt.close(fig2b)


# ══════════════════════════════════════════════════════════════════════════════
# ▌图3 公用函数
# ══════════════════════════════════════════════════════════════════════════════
x4 = np.arange(len(methods_t4))


def bar4_test(ax, x, vals, title):
    """图3 Test Acc 柱状图。"""
    ax.set_facecolor("white")
    ax.yaxis.grid(True, color="#e0e0e0", linewidth=0.6, zorder=0)
    ax.set_axisbelow(True)
    for i, (v, c) in enumerate(zip(vals, RAMP)):
        ax.bar(x[i], v,
               width=0.58,          # ← [可调] 图3 柱宽
               color=c, edgecolor="white", linewidth=0.5, zorder=3)
    # ★ [可调] 图3 Test Acc 子图中 Ours 柱上数值的位置代码
    # 如果你想手动挪位置，优先修改顶部：
    #   FIG3_OURS_TEST_LABEL_DX
    #   FIG3_OURS_TEST_LABEL_DY
    ax.text(x[-1] + FIG3_OURS_TEST_LABEL_DX,
            vals[-1] + FIG3_OURS_TEST_LABEL_DY,
            f"{vals[-1]:.2f}",
            ha="center", va="bottom",
            fontsize=8.5,           # ← [可调] Ours 数值字号
            color=C_OURS, fontweight="bold")
    # ★ [可调] 图3 横轴方法名（PATE / DP-SGD / QL-PGD / Ours）加粗位置
    # 想改字重，优先修改顶部 FIG3_XTICK_FONTWEIGHT
    texts = apply_xtick_label_tuning(ax, x, labels_short4, XTICK_TUNE_FIG3,
                                     fontsize=9,
                                     fontweight=FIG3_XTICK_FONTWEIGHT)    # ← [可调] 横轴标签字号 / 字重
    apply_special_tick_fontsizes(texts, FIG3_SPECIAL_TICK_FONTS)
    # ★ [可调] 图3 纵轴标题加粗位置
    # 当前字重由顶部 matplotlib.rcParams["axes.labelweight"] 统一控制。
    ax.set_ylabel("Test Acc (%)", labelpad=3)
    ax.set_title(title, pad=6)
    ax.set_ylim(0, max(vals) + 16)
    # ★ [可调] 图3 纵轴刻度数字加粗位置
    # 想改字重，优先修改顶部 FIG3_YTICK_FONTWEIGHT
    set_ytick_fontweight(ax, FIG3_YTICK_FONTWEIGHT)


def bar4_priv(ax, x, vals, title):
    """图3 Priv Acc (Ab) 柱状图。"""
    ax.set_facecolor("white")
    ax.yaxis.grid(True, color="#e0e0e0", linewidth=0.6, zorder=0)
    ax.set_axisbelow(True)

    ax.axhline(50,
               color=C_RANDOM,      # ← [可调] 参考线颜色
               linestyle="--", linewidth=1.2, alpha=0.85, zorder=5)

    for i, (v, c) in enumerate(zip(vals, RAMP)):
        ax.bar(x[i], v,
               width=0.58,          # ← [可调] 图3 隐私子图柱宽
               color=c, edgecolor="white", linewidth=0.5, zorder=3)
        if i == len(vals) - 1:
            # ★ [可调] 图3 Priv Acc 子图中 Ours 柱上数值的位置代码
            # 如果你想手动挪位置，优先修改顶部：
            #   FIG3_OURS_PRIV_LABEL_DX
            #   FIG3_OURS_PRIV_LABEL_DY
            ax.text(x[i] + FIG3_OURS_PRIV_LABEL_DX,
                    v + FIG3_OURS_PRIV_LABEL_DY,
                    f"{v:.2f}",
                    ha="center", va="bottom",
                    fontsize=8.5,    # ← [可调] Ours 数值字号
                    color=C_OURS, fontweight="bold")

    # ★ [可调] 图3 横轴方法名（PATE / DP-SGD / QL-PGD / Ours）加粗位置
    # 想改字重，优先修改顶部 FIG3_XTICK_FONTWEIGHT
    texts = apply_xtick_label_tuning(ax, x, labels_short4, XTICK_TUNE_FIG3,
                                     fontsize=9,
                                     fontweight=FIG3_XTICK_FONTWEIGHT)    # ← [可调] 横轴标签字号 / 字重
    apply_special_tick_fontsizes(texts, FIG3_SPECIAL_TICK_FONTS)
    # ★ [可调] 图3 纵轴标题加粗位置
    # 当前字重由顶部 matplotlib.rcParams["axes.labelweight"] 统一控制。
    ax.set_ylabel("Priv Acc (Ab) (%)", labelpad=3)
    ax.set_title(title, pad=6)
    mn, mx = min(vals), max(vals)
    ax.set_ylim(mn - 3, mx + 8)
    # ★ [可调] 图3 纵轴刻度数字加粗位置
    # 想改字重，优先修改顶部 FIG3_YTICK_FONTWEIGHT
    set_ytick_fontweight(ax, FIG3_YTICK_FONTWEIGHT)

    # ★ 图3 random-guess 文字说明模式
    # 当前默认使用方案2：只在图例中保留说明，不在图里写文字，避免和柱子重叠。
    # 如果你想改成方案1（文字放空白处 + 箭头指向 50% 线），把顶部
    # FIG3_RANDOM_GUESS_MODE 改成 "arrow_note" 即可。
    if FIG3_RANDOM_GUESS_MODE == "arrow_note":
        draw_random_guess_arrow_note(
            ax,
            FIG3_RANDOM_GUESS_NOTE,
            label="Random guess (50%)",
        )


# ══════════════════════════════════════════════════════════════════════════════
# ▌图3：跨范式 DP / 正则化基线对比  →  输出为 privacy_*.pdf/png
# ══════════════════════════════════════════════════════════════════════════════

# 图3 图例（简洁版，颜色梯度 + Ours）
leg3_handles = [
    mpatches.Patch(color=RAMP[0], label="PATE"),
    mpatches.Patch(color=RAMP[1], label="DP-SGD (ε=198.5)"),
    mpatches.Patch(color=RAMP[2], label="DP-SGD (ε=50.2)"),
    mpatches.Patch(color=RAMP[3], label="HierarchicalDP"),
    mpatches.Patch(color=RAMP[4], label="QL-PGD"),
    mpatches.Patch(color=C_OURS,  label="Ours"),
    Line2D([0], [0], linestyle="--", color=C_RANDOM,
           linewidth=1.2, label="Random guess"),
]

# ── Figure 3a：CIFAR-10 ── 输出名：privacy_cifar10 ───────────────────────────
fig3a, ax3a = plt.subplots(1, 2,
                            figsize=(7.6, 3.4),   # ← [可调] 图3 画布尺寸
                            constrained_layout=True)

bar4_test(ax3a[0], x4, t4_c_test, "(a) Test Acc (%)")
bar4_priv(ax3a[1], x4, t4_c_Ab,   "(b) Priv Acc (Ab) (%)")

# ★ [可调] 图3a 图例位置（紧贴图上方）
fig3a.legend(handles=leg3_handles,
             loc="lower center",
             bbox_to_anchor=(0.5, -0.20),    # ← [可调] 图例位置
             ncol=4,                          # ← [可调] 图例列数
             frameon=True, handlelength=1.3,
             handletextpad=0.5, columnspacing=0.8,
             borderpad=0.5)

for fmt in ("pdf", "png"):
    fig3a.savefig(os.path.join(OUT, f"privacy_cifar10.{fmt}"),
                  format=fmt, bbox_inches="tight", dpi=300)
print("Figure 3a (privacy_cifar10) saved.")
plt.close(fig3a)

# ── Figure 3b：STL-10 ── 输出名：privacy_stl10 ───────────────────────────────
fig3b, ax3b = plt.subplots(1, 2,
                            figsize=(7.6, 3.4),   # ← [可调] 画布尺寸
                            constrained_layout=True)

bar4_test(ax3b[0], x4, t4_s_test, "(a) Test Acc (%)")
bar4_priv(ax3b[1], x4, t4_s_Ab,   "(b) Priv Acc (Ab) (%)")

# ★ [可调] 图3b 图例位置（同 3a）
fig3b.legend(handles=leg3_handles,
             loc="lower center",
             bbox_to_anchor=(0.5, -0.20),    # ← [可调] 图例位置
             ncol=4, frameon=True, handlelength=1.3,
             handletextpad=0.5, columnspacing=0.8,
             borderpad=0.5)

for fmt in ("pdf", "png"):
    fig3b.savefig(os.path.join(OUT, f"privacy_stl10.{fmt}"),
                  format=fmt, bbox_inches="tight", dpi=300)
print("Figure 3b (privacy_stl10) saved.")
plt.close(fig3b)

print("All figures saved to", OUT)
