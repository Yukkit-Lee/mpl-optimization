# 创建 check_teachers.py
import torch

# 加载两个教师模型
teacher_a = torch.load('teacher_a_resnet18.pth', map_location='cpu')
teacher_b = torch.load('teacher_b_resnet18.pth', map_location='cpu')

# 检查第一层卷积的权重是否相同
w_a = list(teacher_a.values())[0]
w_b = list(teacher_b.values())[0]

print(f"教师A第一层权重均值: {w_a.mean():.6f}")
print(f"教师B第一层权重均值: {w_b.mean():.6f}")
print(f"是否完全相同: {torch.allclose(w_a, w_b)}")