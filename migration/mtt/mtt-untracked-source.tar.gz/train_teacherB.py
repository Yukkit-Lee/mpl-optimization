"""
训练医院B专用的教师模型 Teacher_B
使用 CIFAR-10 数据集，但与 Teacher_A 完全独立训练
由于随机种子不同、数据加载顺序不同，会得到不同的权重
"""

import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
from torchvision.models import resnet18
import os
import random
import numpy as np

# ==========================================
# 设置不同的随机种子，确保 Teacher_B 与 Teacher_A 不同
# ==========================================
def set_seed(seed=42):
    """设置随机种子，确保可重复性但产生不同结果"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

# 医院B使用不同的种子 (与医院A不同)
set_seed(2024)  # 你可以改成任意不同的数字，比如 2024, 1234, 9999 等
print(f"使用随机种子: 2024 (确保 Teacher_B 与 Teacher_A 不同)")

def train_teacher_B():
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print("设备:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU")

    # ==========================================
    # 1. 数据预处理 (与 Teacher_A 完全相同)
    # ==========================================
    transform_train = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
    ])

    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
    ])

    # 同样使用 CIFAR-10，但数据加载顺序会因随机种子不同而不同
    trainset = torchvision.datasets.CIFAR10(root='./data', train=True, download=True, transform=transform_train)
    trainloader = torch.utils.data.DataLoader(trainset, batch_size=128, shuffle=True, num_workers=4)

    testset = torchvision.datasets.CIFAR10(root='./data', train=False, download=True, transform=transform_test)
    testloader = torch.utils.data.DataLoader(testset, batch_size=100, shuffle=False, num_workers=4)

    # ==========================================
    # 2. 网络构建 (与 Teacher_A 完全相同)
    # ==========================================
    net = resnet18(num_classes=10)
    net.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
    net.maxpool = nn.Identity()
    net = net.to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(net.parameters(), lr=0.1, momentum=0.9, weight_decay=5e-4)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=200)

    best_acc = 0
    best_epoch = 0

    # ==========================================
    # 3. 训练与验证循环
    # ==========================================
    print("\n开始训练医院B的教师模型 Teacher_B (200 Epochs)...")
    print("=" * 60)
    
    for epoch in range(50):
        # --- 训练阶段 ---
        net.train()
        train_loss = 0
        for inputs, targets in trainloader:
            inputs, targets = inputs.to(device), targets.to(device)
            optimizer.zero_grad()
            outputs = net(inputs)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()

        # --- 验证阶段 ---
        net.eval()
        correct = 0
        total = 0
        with torch.no_grad():
            for inputs, targets in testloader:
                inputs, targets = inputs.to(device), targets.to(device)
                outputs = net(inputs)
                _, predicted = outputs.max(1)
                total += targets.size(0)
                correct += predicted.eq(targets).sum().item()

        acc = 100. * correct / total
        scheduler.step()

        # 每20轮打印一次日志
        if (epoch + 1) % 5 == 0:
            print(f'Epoch {epoch+1:3d}/200 | Train Loss: {train_loss/len(trainloader):.3f} | Test Acc: {acc:.2f}%')

        # --- 保存最佳模型 ---
        if acc > best_acc:
            best_acc = acc
            best_epoch = epoch + 1
            # 保存为 teacher_b_resnet18.pth，与 Teacher_A 区分
            torch.save(net.state_dict(), 'teacher_b_resnet18.pth')
            print(f'  👑 Epoch {epoch+1}: 新最佳准确率 {acc:.2f}%，已保存到 teacher_b_resnet18.pth')

    print("=" * 60)
    print(f"训练完成！")
    print(f"Teacher_B 最佳准确率: {best_acc:.2f}% (第 {best_epoch} 轮)")
    print(f"模型已保存到: teacher_b_resnet18.pth")
    
    # 验证文件是否成功保存
    if os.path.exists('teacher_b_resnet18.pth'):
        print("✅ 教师模型文件已生成")
    else:
        print("❌ 模型文件保存失败")

if __name__ == '__main__':
    train_teacher_B()