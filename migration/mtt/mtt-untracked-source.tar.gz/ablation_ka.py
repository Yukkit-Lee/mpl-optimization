"""
Knowledge Alignment Ablation Study — Table 7 (Expanded)
=========================================================
消融实验：逐步验证 KA 三个子模块的贡献，用于论文 Table 7 的扩展版本。

新 Table 7 结构:
  Configuration             | Stat.Norm | Conf.Weight | Label Corr | Test Acc | PrivAcc(Ab)
  MPC (no alignment)        |    ✗      |      ✗      |     ✗      |  63.94   |   50.09
  + Statistical only        |    ✓      |      ✗      |     ✗      |  64.18   |   50.04
  + Statistical+Confidence  |    ✓      |      ✓      |     ✗      |  64.31   |   49.71
  + Full KA                 |    ✓      |      ✓      |     ✓      |  64.36   |   49.62

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【MIA 协议（与 mia_attack.py 完全一致）】

  成员  = Teacher 直接训练过的原始私有图像（CIFAR-10 / STL-10 训练集前半段）
  非成员 = Teacher 和 Student 均未直接训练的留出图像（训练集后半段）
  攻击  = Ab（黑盒，MLP，置信度向量+one-hot，20维）

  注意：这与旧版用蒸馏图像作为成员的错误设计不同；
        本版本与 mia_attack.py 采用相同的成员/非成员定义。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
运行方式（需先从 3PC 实验生成缓存）：

  Step 1：在 3pc_generic.py 的 ServerParty.__init__ 末尾加入以下代码，
          运行一次完整 3PC 流程，生成 float 缓存：

            from ablation_ka import save_float_cache
            save_float_cache(
                self.batches_per_hospital['hospital_a'],
                self.batches_per_hospital['hospital_b'],
                f"ka_cache_{HOSPITAL_CONFIGS['hospital_a']['dataset']}.pkl"
            )

  Step 2：运行消融实验：
            python ablation_ka.py --dataset cifar10
            python ablation_ka.py --dataset stl10
            python ablation_ka.py --dataset both     # 默认，顺序运行两个

依赖：与 3pc_generic.py 同目录，需要 utils.py
"""

import argparse
import os
import sys
import pickle
import time
import copy
import socket
import threading
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from datetime import datetime

# ── 依赖 ────────────────────────────────────────────────────────────────────
try:
    from utils import get_network
except ImportError:
    raise ImportError("找不到 utils.py，请确保本脚本与 3pc_generic.py 在同一目录。")

try:
    from nssmpc.primitives.secret_sharing.arithmetic import RingTensor
    HAS_NSSMPC = True
except ImportError:
    HAS_NSSMPC = False
    print("[警告] 未找到 nssmpc，只能从缓存文件加载数据（不影响消融实验本身）。")

# ================================================================
#  ★ 配置区（与 3pc_generic.py 及 mia_attack.py 保持一致）
# ================================================================

DATASET_CONFIGS = {
    'cifar10': {
        'mean'        : (0.4914, 0.4822, 0.4465),
        'std'         : (0.2023, 0.1994, 0.2010),
        'native_size' : (32, 32),
        'num_classes' : 10,
        'test_dataset': lambda root, tf: torchvision.datasets.CIFAR10(
            root=root, train=False, download=True, transform=tf),
        # MIA：原始训练集（用于提取成员/非成员）
        'train_dataset': lambda root, tf: torchvision.datasets.CIFAR10(
            root=root, train=True, download=True, transform=tf),
        'teacher_train_size': 25000,   # 前 N 张为 Teacher 私有数据（成员）
        'n_attack_pairs'    : 2500,    # MIA 每侧样本数（与 mia_attack.py 一致）
    },
    'stl10': {
        'mean'        : (0.4467, 0.4398, 0.4066),
        'std'         : (0.2603, 0.2566, 0.2713),
        'native_size' : (96, 96),
        'num_classes' : 10,
        'test_dataset': lambda root, tf: torchvision.datasets.STL10(
            root=root, split='test', download=True, transform=tf),
        'train_dataset': lambda root, tf: torchvision.datasets.STL10(
            root=root, split='train', download=True, transform=tf),
        'teacher_train_size': 2500,
        'n_attack_pairs'    : 1000,
    },
}

# 消融实验数据集配置
ABLATION_DATASET_MAP = {
    'cifar10': {
        'port_a'     : 9991,
        'port_b'     : 9992,
        'target_size': (32, 32),
        'cache_file' : 'ka_cache_cifar10.pkl',
        'dataset_key': 'cifar10',
    },
    'stl10': {
        'port_a'     : 9993,
        'port_b'     : 9994,
        'target_size': (32, 32),
        'cache_file' : 'ka_cache_stl10.pkl',
        'dataset_key': 'stl10',
    },
}

# 训练超参（与主脚本一致）
T_TEMP     = 4.0
ALPHA      = 0.5
BATCH_SIZE = 256
EPOCHS     = 1000
FP_SCALE   = 2 ** 16

# MIA 参数（与 mia_attack.py 一致）
ATTACK_TRAIN_RATIO = 0.70
N_REPEAT           = 5
RANDOM_SEED        = 42

device = 'cuda' if torch.cuda.is_available() else 'cpu'

# ================================================================
#  四种消融配置（对应论文新 Table 7）
# ================================================================
ABLATION_CONFIGS = [
    {
        'name'        : 'MPC (no alignment)',
        'stat_norm'   : False,
        'conf_weight' : False,
        'label_corr'  : False,
        'symbol'      : ('✗', '✗', '✗'),
    },
    {
        'name'        : '+ Statistical only',
        'stat_norm'   : True,
        'conf_weight' : False,
        'label_corr'  : False,
        'symbol'      : ('✓', '✗', '✗'),
    },
    {
        'name'        : '+ Statistical + Confidence',
        'stat_norm'   : True,
        'conf_weight' : True,
        'label_corr'  : False,
        'symbol'      : ('✓', '✓', '✗'),
    },
    {
        'name'        : '+ Full KA',
        'stat_norm'   : True,
        'conf_weight' : True,
        'label_corr'  : True,
        'symbol'      : ('✓', '✓', '✓'),
    },
]


# ================================================================
#  定点编解码
# ================================================================
def float_to_ring(t: torch.Tensor) -> 'RingTensor':
    assert t.device.type == 'cpu'
    return RingTensor((t * FP_SCALE).round().long())


def ring_to_float(ring_data, tgt_dev: str) -> torch.Tensor:
    if HAS_NSSMPC and isinstance(ring_data, RingTensor):
        return (ring_data.convert_to_real_field().float() / FP_SCALE).to(tgt_dev)
    if isinstance(ring_data, torch.Tensor):
        return ring_data.float().to(tgt_dev)
    raise TypeError(f"未知数据类型: {type(ring_data)}")


# ================================================================
#  数据增强
# ================================================================
class DiffAugment(nn.Module):
    def __init__(self, target_size=(32, 32)):
        super().__init__()
        pad = target_size[0] // 8
        self.aug = nn.Sequential(
            transforms.RandomCrop(target_size[0], padding=pad),
            transforms.RandomHorizontalFlip(),
        )
    def forward(self, x):
        return self.aug(x)


# ================================================================
#  ★ 可配置的 KnowledgeAligner（支持逐步开关三个子模块）
# ================================================================
class KnowledgeAlignerAblation:
    """
    与原 KnowledgeAligner 逻辑完全一致，新增三个布尔开关：
      use_stat_norm   : 开关 Step 1（统计对齐）
      use_conf_weight : 开关 Step 2（置信度加权）
      use_label_corr  : 开关 Step 3（标签条件修正）
    全为 False 时，logits 原样返回（no alignment 基线）。
    """

    def __init__(self,
                 num_classes    : int  = 10,
                 use_stat_norm  : bool = True,
                 use_conf_weight: bool = True,
                 use_label_corr : bool = True):
        self.num_classes     = num_classes
        self.use_stat_norm   = use_stat_norm
        self.use_conf_weight = use_conf_weight
        self.use_label_corr  = use_label_corr
        self.fitted          = False
        self.mean_a = self.std_a = None
        self.mean_b = self.std_b = None
        self.mean_global = self.std_global = None
        self.conf_a = self.conf_b = None

    @torch.no_grad()
    def fit(self, batches_a: list, batches_b: list, dev: str):
        logits_a   = torch.cat([ring_to_float(b['logits_ring'], 'cpu') for b in batches_a], 0)
        logits_b   = torch.cat([ring_to_float(b['logits_ring'], 'cpu') for b in batches_b], 0)
        logits_all = torch.cat([logits_a, logits_b], 0)

        mean_a      = logits_a.mean(0);   std_a  = logits_a.std(0).clamp(min=1e-6)
        mean_b      = logits_b.mean(0);   std_b  = logits_b.std(0).clamp(min=1e-6)
        mean_global = logits_all.mean(0)
        std_global  = logits_all.std(0).clamp(min=1e-6)
        conf_a      = F.softmax(logits_a / T_TEMP, 1).mean(0)
        conf_b      = F.softmax(logits_b / T_TEMP, 1).mean(0)

        self.mean_a      = mean_a.to(dev);      self.std_a      = std_a.to(dev)
        self.mean_b      = mean_b.to(dev);      self.std_b      = std_b.to(dev)
        self.mean_global = mean_global.to(dev); self.std_global = std_global.to(dev)
        self.conf_a      = conf_a.to(dev);      self.conf_b     = conf_b.to(dev)
        self.fitted      = True

    def align(self, logits: torch.Tensor, source: str,
              labels: torch.Tensor) -> torch.Tensor:
        if not any([self.use_stat_norm, self.use_conf_weight, self.use_label_corr]):
            return logits

        assert self.fitted
        is_a = source in ('hospital_a', 'a')
        src_mean, src_std = (self.mean_a, self.std_a) if is_a else (self.mean_b, self.std_b)
        src_conf, oth_conf = (self.conf_a, self.conf_b) if is_a else (self.conf_b, self.conf_a)

        aligned = logits.clone()

        if self.use_stat_norm:
            aligned = (aligned - src_mean) / src_std * self.std_global + self.mean_global

        if self.use_conf_weight:
            conf_w  = src_conf / (src_conf + oth_conf + 1e-8)
            aligned = (conf_w.unsqueeze(0) * aligned
                       + (1.0 - conf_w).unsqueeze(0) * self.mean_global.unsqueeze(0))

        if self.use_label_corr:
            for i in range(logits.size(0)):
                c = labels[i].item()
                aligned[i, c] = aligned[i, c] + 0.5 * self.std_global[c]

        return aligned


# ================================================================
#  测试集构建
# ================================================================
def build_test_loader(dataset_key: str, target_size: tuple,
                      data_root: str = './data'):
    cfg    = DATASET_CONFIGS[dataset_key]
    t_list = [transforms.ToTensor()]
    if target_size != cfg['native_size']:
        t_list.append(transforms.Resize(target_size))
    t_list.append(transforms.Normalize(cfg['mean'], cfg['std']))
    tf = transforms.Compose(t_list)
    ds = cfg['test_dataset'](data_root, tf)
    return torch.utils.data.DataLoader(
        ds, batch_size=256, shuffle=False, num_workers=2)


# ================================================================
#  ★ MIA（与 mia_attack.py 协议完全一致）
#  成员  = Teacher 私有原始训练数据（训练集前 teacher_train_size 张）
#  非成员 = 留出集（训练集后半段）
# ================================================================

def load_mia_data(dataset_key: str, target_size: tuple,
                  data_root: str = './data'):
    """
    加载成员/非成员数据，与 mia_attack.py 中的 get_member_nonmember_split 逻辑一致。
    STL-10 图像统一 Resize 到 target_size（32×32）。
    """
    cfg = DATASET_CONFIGS[dataset_key]
    t_list = [transforms.ToTensor()]
    if target_size != cfg['native_size']:
        t_list.append(transforms.Resize(target_size))
    t_list.append(transforms.Normalize(cfg['mean'], cfg['std']))
    tf = transforms.Compose(t_list)

    print(f"      加载 {dataset_key.upper()} 原始训练集用于 MIA...")
    ds = cfg['train_dataset'](data_root, tf)
    imgs   = torch.stack([ds[i][0] for i in range(len(ds))])
    labels = torch.tensor([ds[i][1] for i in range(len(ds))], dtype=torch.long)

    n = cfg['teacher_train_size']
    member_data    = (imgs[:n], labels[:n])
    nonmember_data = (imgs[n:], labels[n:])
    print(f"      成员   : 前 {n} 张（Teacher 私有训练数据）")
    print(f"      非成员 : 后 {len(imgs)-n} 张（留出集）")
    return member_data, nonmember_data


@torch.no_grad()
def _extract_signals(model: nn.Module, images: torch.Tensor,
                     labels: torch.Tensor, dev: str) -> np.ndarray:
    """提取黑盒攻击信号：softmax 置信度向量(10) + one-hot(10) = 20维"""
    model.eval()
    conf_vecs = []
    one_hots  = []
    for start in range(0, len(images), 256):
        imgs = images[start:start+256].to(dev)
        labs = labels[start:start+256].to(dev)
        probs = F.softmax(model(imgs), dim=1).cpu()
        conf_vecs.append(probs)
        one_hots.append(F.one_hot(labs.cpu(), 10).float())

    conf_vecs = torch.cat(conf_vecs, 0)
    one_hots  = torch.cat(one_hots, 0)
    return torch.cat([conf_vecs, one_hots], dim=1).numpy()


def run_mia_ab(model          : nn.Module,
               member_data    : tuple,
               nonmember_data : tuple,
               n_attack_pairs : int,
               dev            : str) -> float:
    """
    黑盒 MIA（Ab），与 mia_attack.py run_attack_once 完全一致。
    返回 N_REPEAT 次的均值准确率（%）。
    """
    member_imgs,    member_labels    = member_data
    nonmember_imgs, nonmember_labels = nonmember_data

    n_eval = min(n_attack_pairs * 3, len(member_imgs), len(nonmember_imgs))
    torch.manual_seed(RANDOM_SEED)
    m_idx  = torch.randperm(len(member_imgs))[:n_eval]
    nm_idx = torch.randperm(len(nonmember_imgs))[:n_eval]

    feat_m  = _extract_signals(model, member_imgs[m_idx],    member_labels[m_idx],    dev)
    feat_nm = _extract_signals(model, nonmember_imgs[nm_idx], nonmember_labels[nm_idx], dev)

    accs = []
    for r in range(N_REPEAT):
        np.random.seed(RANDOM_SEED + r)
        n = min(n_attack_pairs, len(feat_m), len(feat_nm))
        idx_m  = np.random.choice(len(feat_m),  n, replace=False)
        idx_nm = np.random.choice(len(feat_nm), n, replace=False)

        X = np.concatenate([feat_m[idx_m], feat_nm[idx_nm]], 0)
        y = np.concatenate([np.ones(n), np.zeros(n)])

        X_tr, X_te, y_tr, y_te = train_test_split(
            X, y, test_size=1-ATTACK_TRAIN_RATIO,
            random_state=RANDOM_SEED+r, stratify=y)

        scaler = StandardScaler()
        X_tr   = scaler.fit_transform(X_tr)
        X_te   = scaler.transform(X_te)

        clf = MLPClassifier(
            hidden_layer_sizes=(128, 64), activation='relu', solver='adam',
            max_iter=300, random_state=RANDOM_SEED+r,
            early_stopping=True, validation_fraction=0.1, n_iter_no_change=15)
        clf.fit(X_tr, y_tr)
        accs.append(accuracy_score(y_te, clf.predict(X_te)) * 100.0)

    return float(np.mean(accs))


# ================================================================
#  缓存：保存 / 加载解密后的 float 批次
# ================================================================
def save_float_cache(batches_a: list, batches_b: list, cache_file: str):
    """
    将加密 batch 解码为 float 后序列化存盘。
    在 3pc_generic.py 的 ServerParty.__init__ 末尾调用此函数即可生成缓存。
    """
    print(f"  保存 float 缓存到 {cache_file} ...")

    def decode(batches):
        out = []
        for b in batches:
            out.append({
                'imgs'  : ring_to_float(b['imgs_ring'],   'cpu'),
                'logits': ring_to_float(b['logits_ring'], 'cpu'),
                'labels': b['labels'],
                'source': b.get('source', 'hospital_a'),
            })
        return out

    with open(cache_file, 'wb') as f:
        pickle.dump({'batches_a': decode(batches_a),
                     'batches_b': decode(batches_b)}, f)
    print(f"  缓存已保存 ({os.path.getsize(cache_file)/1e6:.1f} MB)")


def load_float_cache(cache_file: str) -> tuple:
    """从 float 缓存加载，返回 (batches_a, batches_b)"""
    print(f"  从缓存加载: {cache_file}")
    with open(cache_file, 'rb') as f:
        cache = pickle.load(f)

    def wrap(decoded):
        return [{
            'imgs_ring'  : b['imgs'],
            'logits_ring': b['logits'],
            'labels'     : b['labels'],
            'source'     : b['source'],
        } for b in decoded]

    ba = wrap(cache['batches_a'])
    bb = wrap(cache['batches_b'])
    print(f"  加载完成：A={len(ba)} batch，B={len(bb)} batch")
    return ba, bb


# ================================================================
#  Socket 接收（仅在无缓存时调用）
# ================================================================
class _DataReceiver:
    HEADER = 8

    @staticmethod
    def receive(port: int, timeout: int = 600):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.settimeout(timeout)
        s.bind(('0.0.0.0', port))
        s.listen(1)
        print(f"      监听端口 {port}...")
        conn, addr = s.accept()
        print(f"      收到来自 {addr}")
        length = int.from_bytes(conn.recv(_DataReceiver.HEADER), 'big')
        buf = b''
        while len(buf) < length:
            chunk = conn.recv(min(65536, length - len(buf)))
            if not chunk:
                break
            buf += chunk
        conn.close(); s.close()
        return pickle.loads(buf)


def receive_from_hospitals(port_a: int, port_b: int) -> tuple:
    result = {}

    def recv_one(key, port):
        data = _DataReceiver.receive(port)
        for b in data['batches']:
            b['source'] = key
        result[key] = data['batches']

    threads = [
        threading.Thread(target=recv_one, args=('hospital_a', port_a), daemon=True),
        threading.Thread(target=recv_one, args=('hospital_b', port_b), daemon=True),
    ]
    for t in threads: t.start()
    for t in threads: t.join()
    return result.get('hospital_a', []), result.get('hospital_b', [])


# ================================================================
#  单次训练 + 评估
# ================================================================
def train_one_config(all_batches       : list,
                     batches_a         : list,
                     batches_b         : list,
                     test_loader,
                     ka_cfg            : dict,
                     target_size       : tuple,
                     num_classes       : int,
                     member_data       : tuple,
                     nonmember_data    : tuple,
                     n_attack_pairs    : int,
                     seed              : int = 42) -> dict:
    torch.manual_seed(seed)
    np.random.seed(seed)

    # ── 初始化 Student ──────────────────────────────────────────────
    student = get_network(
        'ConvNet', channel=3, num_classes=num_classes, im_size=target_size
    ).to(device)

    optimizer = torch.optim.SGD(
        student.parameters(), lr=0.01, momentum=0.9, weight_decay=5e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=EPOCHS)
    augmentor = DiffAugment(target_size=target_size).to(device)

    # ── 初始化 KA ──────────────────────────────────────────────────
    aligner = KnowledgeAlignerAblation(
        num_classes     = num_classes,
        use_stat_norm   = ka_cfg['stat_norm'],
        use_conf_weight = ka_cfg['conf_weight'],
        use_label_corr  = ka_cfg['label_corr'],
    )
    if any([ka_cfg['stat_norm'], ka_cfg['conf_weight'], ka_cfg['label_corr']]):
        aligner.fit(batches_a, batches_b, device)

    num_batches = len(all_batches)
    best_acc    = 0.0
    best_state  = None

    # ── 训练循环 ────────────────────────────────────────────────────
    for epoch in range(EPOCHS):
        student.train()
        perm = np.random.permutation(num_batches)

        for bi in perm:
            batch  = all_batches[bi]
            imgs   = ring_to_float(batch['imgs_ring'],   device)
            logits = ring_to_float(batch['logits_ring'], device)
            labels = torch.tensor(batch['labels'], dtype=torch.long).to(device)

            source         = batch.get('source', 'hospital_a')
            aligned_logits = aligner.align(logits, source, labels)
            imgs           = augmentor(imgs)
            student_logits = student(imgs)

            kd_loss = F.kl_div(
                F.log_softmax(student_logits   / T_TEMP, dim=1),
                F.softmax(aligned_logits / T_TEMP, dim=1),
                reduction='batchmean'
            ) * (T_TEMP ** 2)
            ce_loss = F.cross_entropy(student_logits, labels)
            loss    = ALPHA * kd_loss + (1 - ALPHA) * ce_loss

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        scheduler.step()

        if (epoch + 1) % 100 == 0:
            student.eval()
            correct = total = 0
            with torch.no_grad():
                for imgs_t, lbls_t in test_loader:
                    preds = student(imgs_t.to(device)).argmax(1)
                    correct += preds.eq(lbls_t.to(device)).sum().item()
                    total   += lbls_t.size(0)
            acc = 100.0 * correct / total
            if acc > best_acc:
                best_acc   = acc
                best_state = copy.deepcopy(student.state_dict())
            print(f"      Epoch {epoch+1:4d}  acc={acc:.2f}  best={best_acc:.2f}")

    if best_state is not None:
        student.load_state_dict(best_state)

    # ── MIA 评估（与 mia_attack.py 协议一致）──────────────────────
    print("      运行 MIA（Ab）评估...")
    priv_acc = run_mia_ab(student, member_data, nonmember_data,
                          n_attack_pairs, device)

    return {'test_acc': best_acc, 'priv_acc': priv_acc}


# ================================================================
#  主消融函数
# ================================================================
def run_ablation(dataset_tag: str, args):
    ds_cfg     = ABLATION_DATASET_MAP[dataset_tag]
    ds_key     = ds_cfg['dataset_key']
    target_size = ds_cfg['target_size']
    cfg_ds     = DATASET_CONFIGS[ds_key]
    num_classes = cfg_ds['num_classes']
    cache_file  = ds_cfg['cache_file']

    print(f"\n{'='*72}")
    print(f"  消融实验 ── 数据集: {dataset_tag.upper()}")
    print(f"  target_size={target_size}  num_classes={num_classes}")
    print(f"{'='*72}")

    # ── 获取 batch 数据 ─────────────────────────────────────────────
    if os.path.exists(cache_file) and not args.force_receive:
        batches_a, batches_b = load_float_cache(cache_file)
    else:
        if not HAS_NSSMPC:
            raise RuntimeError(
                f"缓存文件 {cache_file} 不存在，且未安装 nssmpc。\n"
                "请先在 3pc_generic.py 中调用 save_float_cache() 生成缓存。")
        print(f"  接收来自医院的数据（端口 A:{ds_cfg['port_a']} B:{ds_cfg['port_b']}）...")
        batches_a, batches_b = receive_from_hospitals(
            ds_cfg['port_a'], ds_cfg['port_b'])
        save_float_cache(batches_a, batches_b, cache_file)

    all_batches = []
    for b in batches_a:
        b['source'] = 'hospital_a'; all_batches.append(b)
    for b in batches_b:
        b['source'] = 'hospital_b'; all_batches.append(b)
    print(f"  合计 batch 数: {len(all_batches)}")

    # ── 测试集 ──────────────────────────────────────────────────────
    test_loader = build_test_loader(ds_key, target_size)

    # ── MIA 数据（与 mia_attack.py 完全一致的成员/非成员划分）──────
    print("\n  加载 MIA 成员/非成员数据...")
    member_data, nonmember_data = load_mia_data(ds_key, target_size)
    n_attack_pairs = cfg_ds['n_attack_pairs']

    # ── 逐配置训练 ───────────────────────────────────────────────────
    results = []
    for cfg in ABLATION_CONFIGS:
        print(f"\n  ── 配置: [{cfg['name']}]  "
              f"StatNorm={cfg['stat_norm']}  "
              f"ConfWeight={cfg['conf_weight']}  "
              f"LabelCorr={cfg['label_corr']}")
        t0 = time.time()
        res = train_one_config(
            all_batches    = all_batches,
            batches_a      = batches_a,
            batches_b      = batches_b,
            test_loader    = test_loader,
            ka_cfg         = cfg,
            target_size    = target_size,
            num_classes    = num_classes,
            member_data    = member_data,
            nonmember_data = nonmember_data,
            n_attack_pairs = n_attack_pairs,
            seed           = args.seed,
        )
        elapsed = time.time() - t0
        results.append({**cfg, **res, 'time_min': elapsed / 60})
        print(f"  ✓ Test Acc={res['test_acc']:.2f}%  "
              f"Priv Acc(Ab)={res['priv_acc']:.2f}%  "
              f"用时 {elapsed/60:.1f} min")

    return results


# ================================================================
#  打印 & 保存 Table
# ================================================================
def print_and_save_table(results_dict: dict):
    sep = "─" * 92
    ts  = datetime.now().strftime('%Y%m%d_%H%M%S')
    csv_lines = ["Dataset,Configuration,StatNorm,ConfWeight,LabelCorr,"
                 "TestAcc(%),PrivAcc_Ab(%)"]

    for ds_tag, results in results_dict.items():
        print(f"\n\n{'='*92}")
        print(f"  Table 7 (Expanded) — {ds_tag.upper()}")
        print(sep)
        print(f"  {'Configuration':<34} "
              f"{'Stat.Norm':<11} {'Conf.Wt.':<11} {'Label.Cr':<11} "
              f"{'Test Acc(%)':<13} {'PrivAcc(Ab)(%)'}  ")
        print(sep)
        for r in results:
            sym = r['symbol']
            print(f"  {r['name']:<34} "
                  f"{sym[0]:<11} {sym[1]:<11} {sym[2]:<11} "
                  f"{r['test_acc']:<13.2f} {r['priv_acc']:.2f}")
            csv_lines.append(
                f"{ds_tag.upper()},{r['name']},"
                f"{r['stat_norm']},{r['conf_weight']},{r['label_corr']},"
                f"{r['test_acc']:.2f},{r['priv_acc']:.2f}")
        print(sep)

    csv_path = f'ablation_table7_{ts}.csv'
    with open(csv_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(csv_lines))
    print(f"\n  结果已保存至: {csv_path}")


# ================================================================
#  命令行入口
# ================================================================
def parse_args():
    p = argparse.ArgumentParser(description='KA Ablation Study (Table 7 Expanded)')
    p.add_argument('--dataset',
                   choices=['cifar10', 'stl10', 'both'],
                   default='both',
                   help='要运行消融实验的数据集（默认: both）')
    p.add_argument('--force_receive',
                   action='store_true',
                   help='忽略缓存，强制重新从医院接收数据')
    p.add_argument('--seed',
                   type=int,
                   default=42,
                   help='随机种子（默认: 42）')
    p.add_argument('--save_cache_only',
                   action='store_true',
                   help='仅接收并保存缓存，不运行消融训练')
    return p.parse_args()


def main():
    args = parse_args()

    print("=" * 72)
    print("  KA Ablation Experiment — Table 7 (Expanded)")
    print(f"  Dataset: {args.dataset.upper()}")
    print(f"  PyTorch: {torch.__version__}  CUDA: {torch.cuda.is_available()}")
    print(f"  Device:  {device}  Seed: {args.seed}")
    print(f"  Epochs:  {EPOCHS}")
    print(f"  MIA协议: 成员=Teacher原始训练集，非成员=留出集（与mia_attack.py一致）")
    print("=" * 72)

    datasets_to_run = ['cifar10', 'stl10'] if args.dataset == 'both' else [args.dataset]

    if args.save_cache_only:
        for ds_tag in datasets_to_run:
            ds_cfg = ABLATION_DATASET_MAP[ds_tag]
            print(f"\n缓存模式 ── 接收 {ds_tag.upper()} 数据...")
            ba, bb = receive_from_hospitals(ds_cfg['port_a'], ds_cfg['port_b'])
            save_float_cache(ba, bb, ds_cfg['cache_file'])
        print("\n缓存保存完成。")
        return

    all_results = {}
    for ds_tag in datasets_to_run:
        all_results[ds_tag] = run_ablation(ds_tag, args)

    print_and_save_table(all_results)


if __name__ == '__main__':
    main()