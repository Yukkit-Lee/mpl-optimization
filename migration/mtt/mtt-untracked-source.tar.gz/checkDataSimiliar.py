import torch
import glob

# 找到两个文件
files = glob.glob("**/images_best.pt", recursive=True)
print(f"找到 {len(files)} 个蒸馏数据文件")

if len(files) >= 2:
    data1 = torch.load(files[0])
    data2 = torch.load(files[1])
    
    print(f"文件1: {files[0]}")
    print(f"文件2: {files[1]}")
    print(f"形状相同: {data1.shape == data2.shape}")
    print(f"数值是否相同: {torch.allclose(data1, data2)}")
    print(f"第一个像素: {data1[0,0,0,0].item():.6f} vs {data2[0,0,0,0].item():.6f}")